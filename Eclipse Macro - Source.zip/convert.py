"""
Convert a luvmacro recording (.txt/.json) to this app's format.

    python convert.py MY_RECORDING.txt                   -> recordings/MY_RECORDING.json
    python convert.py MY_RECORDING.txt --failsafe-at 106.3 --start-at 20

--failsafe-at: time (seconds into the recording) where the failsafe part begins.
The app loads luvmacro files directly too, but converting lets you bake the failsafe marker in.
"""
import argparse
import json
import os
import sys

import core


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--failsafe-at", type=float, default=0.0)
    ap.add_argument("--start-at", type=float, default=0.0,
                    help="recording time where the mission starts (after the retry clicks + loading)")
    ap.add_argument("-o", "--output")
    a = ap.parse_args()

    with open(a.input, "r", encoding="utf-8") as f:
        data = json.load(f)
    if data.get("format") != "luvmacro":
        sys.exit("This file is not a luvmacro recording.")
    rec = core.convert_luvmacro(data, a.failsafe_at, a.start_at)

    out = a.output or os.path.join(
        core.RECORDING_DIR, os.path.splitext(os.path.basename(a.input))[0].lower() + ".json")
    core.save_recording(rec, out)

    keys = [e for e in rec["events"] if e["type"] in ("key_down", "key_up")]
    last_key = max((e["t"] for e in keys), default=0)
    clicks = [e for e in rec["events"] if e["type"] == "mouse_down" and e["t"] > last_key]
    print(f"Saved {out}")
    print(f"  {len(rec['events'])} events, {rec['duration']:.1f}s, last key press at "
          f"{max((e['t'] for e in keys), default=0):.1f}s")
    if clicks:
        print(f"  first click after the last key press: {clicks[0]['t']:.1f}s "
              "(the failsafe usually starts a bit before this)")
    print("  failsafe marker:", f"at {a.failsafe_at:g}s" if a.failsafe_at else "none")
    print("  mission starts at:", f"{a.start_at:g}s" if a.start_at else "not set")


if __name__ == "__main__":
    main()
