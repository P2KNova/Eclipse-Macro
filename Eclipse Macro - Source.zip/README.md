# My Macro

Loops a recorded mission automatically and tracks completed / failed. The recording is played exactly
as recorded; the app watches the screen and skips the recording's failsafe if the mission finishes.

## Setup (Windows, Python 3.10+)
    pip install -r requirements.txt
    python macro_app.py

## First-time setup
1. **Load recording...** -> `recordings/freedom_outskirts.json` (remembered next time).
2. **Capture the templates** (pick the name, press *Capture region...*, drag a tight box):
   - `retry` (required): the RETRY button on the end screen.
   - `start` (**strongly recommended**): something that is only visible once you are IN the mission,
     e.g. the skill bar / HUD, and NOT on the end screen or loading screen. This is how the app knows
     the game has loaded (see below). Without it the recording's fixed loading time is used.
   - `result_completed` (**recommended**): the "Mission Completed" banner/text. As soon as it is on
     screen the mission counts as over and the failsafe is skipped - even if the Retry button only
     appears a few seconds later. `result_failed` does the same for a failed mission.
   The files must be named exactly `retry.png`, `start.png`, `result_completed.png`,
   `result_failed.png` in the `templates` folder (the app warns you at Start about other names).
3. **Start**: press F8 while the **end screen** is showing (the recording begins by clicking Retry).
   If you press it elsewhere, the app waits until the end screen appears. F6 pause, F7 stop.
   Slamming the mouse into a screen corner also aborts.
   The app shows a silent 3-2-1 countdown at the top center of the screen before playback starts.

## Optional notifications and window behavior
- Tick **Keep macro window always on top** in Settings to keep the control window above Roblox.
- Set **Discord loot screenshot webhook** to send the detected Mission Completed screenshot to one
  channel, and **Discord log webhook** to send batched macro log lines to a different channel. Each
  field needs a webhook created for its destination channel. Leave either field blank to disable it.
- If Discord returns 403, the log now includes Discord's response details when available. Check that
  the URL is a current webhook URL and that your network/server allows the Discord request.
- The included `freedom_outskirts.json` is the older recording supplied by the user, with its original
  Shift Lock toggles and mouse movement restored. Relative mouse movements play as recorded; absolute
  click positions are still kept within the game capture area.

## How a cycle works
1. On the end screen the recording clicks Retry (only that first part of the recording is played).
2. **The app waits until the game has really loaded** (the `start` template is visible and the Retry
   button is gone), then plays the mission part of the recording. If the Retry click missed, it clicks
   Retry itself after 4 seconds. If the game does not load within *Load timeout* it gives up and waits
   for the end screen again. (No `start` template = the recording's own fixed loading time is used.)
3. A background thread watches during the mission for the end of it: the Retry button, the
   "completed" banner or the "failed" banner - whichever shows first.
4. **End screen appears** -> playback stops immediately, the failsafe is skipped, the result is counted,
   and the next cycle starts (the recording clicks Retry again).
5. **End screen does not appear** -> when the mission has been running **Failsafe after** seconds
   (default 90), the failsafe part of the recording plays (eject, then the thunderspear clicks).
   When the end screen shows up the cycle restarts as in 4.

## The numbers that matter (Settings)
- **Failsafe after (s)** - seconds after the *mission starts* that the failsafe kicks in (default 90).
- **Mission starts at (s)** - recording time where the mission begins. For `freedom_outskirts.json` it is
  20 (the first 5s are Retry clicks, then loading, first real action at 22s). It starts the failsafe timer.
  0 = use the value stored in the file.
- **Failsafe starts at (s)** - recording time where the failsafe part begins (the file has it at 106.3,
  the `5` eject burst). 0 = use the marker in the file.
- **Load timeout (s)** - how long to wait for the game to load after the retry clicks (120).
- **Mission timeout** - how long to wait for the end screen after the recording finished.
- **Match threshold** - 0.85; lower (0.80) if the end screen is not detected.
The event log shows each key it presses and what it decided (mission result, failsafe, ...).

## Windowed mode (game NOT in fullscreen)
The recording stores click positions for the window it was made in (1920x1080 at the top-left). The app
scales them to wherever the game is now, so any window size / position works.
1. Put the game in a window and keep the macro window off it (e.g. on your second monitor) - anything
   covering the game is also what the macro "sees". Do not minimize the game.
2. In Settings tick **Windowed mode** and press **Check window**. The log shows the size and position of
   the game picture it found (the window title must be exactly `Roblox`; change *Window title* if not).
3. Capture your templates with **Capture region...** while the game is in the window. The app remembers
   how big the game was, so the templates still match if you resize the window later.
   (Images taken with other tools, e.g. Win+Shift+S, only match at the size they were taken at.)
4. Start as usual. The log says e.g. `Game window: 1280x720 at (400, 150)` and that the recorded clicks
   are scaled to it. You can move the window between missions.
- 16:9 windows (1280x720, 1600x900, ...) work best. For another shape, if the Retry clicks miss, tick
  *Skip the recording's start*: then the app clicks Retry itself using the picture of the button.
- Fullscreen at another resolution (e.g. 2560x1440) is scaled the same way - nothing to change.

## If it does not notice the end of the mission (failsafe plays anyway / no retry)
1. Finish a mission and stay on the Mission Completed / end screen on the game's monitor.
2. In the app press **Test detection (3s)** (in the Templates box) and read the log. For each image it says
   FOUND or not found, with the match score (needs 0.85). It also saves `debug/screen.png` - open it to see
   exactly what the macro sees; green box = found, red = its best guess.
   - *not found, score low* -> the image was captured from a different-looking screen; capture it again.
   - *"matches at size x0.85"* -> the game is shown at a different size than when you captured the image.
     Recapture it at the current size.
   - *capture is BLACK* -> Windows cannot capture the game (exclusive fullscreen); use borderless fullscreen.
   - *"Looking at: ..."* must be your game's screen (1920x1080 at (0, 0)).
3. When the failsafe starts, the log prints the latest match scores, so you can see how close it was.
The app watches the main screen (the one at position 0,0). To watch another one set
`"capture_monitor": 2` (or 1, 3...) in settings.json.

## Files
- `recordings/freedom_outskirts.json` - your recording, converted, with the failsafe marker (106.3s)
  and mission start (20s) built in. `recordings/*.luvmacro` is the original; the app also loads
  `.luvmacro` / `.txt` directly (then set the two numbers above in Settings).
- Convert another one: `python convert.py MY.luvmacro --failsafe-at 106.3 --start-at 20`
- Recording format (plain JSON, see `recordings/example_format.json`): key_down, key_up, tap, spam,
  mouse_down, mouse_up, move (relative), move_raw (relative), move_abs, scroll,
  failsafe (marker), end.

## Advanced: let the app click Retry itself
Tick *Skip the recording's start*. The app then skips everything before **Mission starts at**, clicks
Retry itself using the template, and starts the recording when the `start` template shows up.
Use this only for a recording that has no Retry clicks in it.

## Tips
- Absolute click positions come from where the game window was when you recorded (0,0 at 1920x1080).
  If yours is elsewhere, set `abs_offset_x` / `abs_offset_y` in settings.json.
- Hotkeys not working in game? Run cmd as Administrator.
- Macros can break a game's rules - use at your own risk.

## Hourly Discord report
Enable **Send hourly loot report** under Settings > Discord Notifications. After each hour, the Loot webhook receives interval and since-start mission totals, runtime, missions per hour, tracked loot icon counts, and the latest mission-complete screenshot. Reports omit PC and rejoin information. The app counts recognized scroll, fragment, serum, and vessel icon categories per completed mission. Windows OCR reads Gold and Gems from the third and fourth reward cards and sums them in both reports; unreadable screens are excluded and shown in the reading count. The first report is sent 60 minutes after starting the macro.

When the macro session stops, Eclipse sends a final session report to the Loot webhook with mission totals, runtime, detected loot counts, and the latest completion screenshot.
