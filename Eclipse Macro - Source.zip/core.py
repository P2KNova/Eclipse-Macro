"""
core.py - the logic of the macro, with no GUI in it.

  Settings / Stats   small JSON files next to the app
  Vision             screenshot + template matching (OpenCV)
  Recorder           records your keyboard / mouse into a JSON "recording"
  Player             replays a recording with accurate timing
  Runner             the mission loop: wait for start -> play -> wait for end -> retry
"""
from __future__ import annotations

import json
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.request
import urllib.error
import uuid
from collections import namedtuple

import cv2
import numpy as np

# --------------------------------------------------------------------------- paths
if getattr(sys, "frozen", False):                      # running as a PyInstaller exe
    APP_DIR = os.path.dirname(sys.executable)           # persistent, writable user data
    RESOURCE_DIR = getattr(sys, "_MEIPASS", APP_DIR)  # bundled one-file resources
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))
    RESOURCE_DIR = APP_DIR

TEMPLATE_DIR = os.path.join(APP_DIR, "templates")
RECORDING_DIR = os.path.join(APP_DIR, "recordings")
SETTINGS_PATH = os.path.join(APP_DIR, "settings.json")
DEBUG_DIR = os.path.join(APP_DIR, "debug")
STATS_PATH = os.path.join(APP_DIR, "stats.json")


def prepare_user_files():
    """Create writable data directories and seed bundled recordings on first launch."""
    os.makedirs(TEMPLATE_DIR, exist_ok=True)
    os.makedirs(RECORDING_DIR, exist_ok=True)
    for bundled_name, user_dir in (("recordings", RECORDING_DIR), ("templates", TEMPLATE_DIR)):
        bundled_dir = os.path.join(RESOURCE_DIR, bundled_name)
        if os.path.isdir(bundled_dir):
            for name in os.listdir(bundled_dir):
                source = os.path.join(bundled_dir, name)
                target = os.path.join(user_dir, name)
                if os.path.isfile(source) and not os.path.exists(target):
                    shutil.copy2(source, target)

# name -> (required?, what it is)
TEMPLATES = {
    "retry": (True, "The RETRY button on the end screen (the app clicks this)"),
    "start": (False, "Something only visible once you are IN the mission (HUD / skill bar). "
                     "Lets the app wait for the game to load before playing the mission part"),
    "result_completed": (False, "The 'Mission Completed' banner/text. Also ENDS the mission "
                                "(skips the failsafe) as soon as it shows, even before Retry appears"),
    "result_failed": (False, "The 'Mission Failed' banner/text. Also ends the mission, like completed"),
}

# Loot icon templates bundled from the user's companion macro. Counts are per
# mission result screen; Gold and Gems are read from their reward cards via Windows OCR.
LOOT_TEMPLATE_FILES = {
    "scroll": "loot_scroll",
    "body_fragment": "loot_body",
    "defence_fragment": "loot_defence",
    "offence_fragment": "loot_offence",
    "support_fragment": "loot_support",
    "armor_serum": "loot_armor_serum",
    "female_serum": "loot_female_serum",
    "beast_serum": "loot_beast_serum",
    "colossal_serum": "loot_colossal_serum",
    "vessel": "loot_vessel",
}
CURRENCY_GOLD_ICON = "currency_gold_icon"
CURRENCY_GEM_ICON = "currency_gem_icon"
PERK_ICON_TEMPLATES = {"epic": "perk_epic_icon", "legendary": "perk_legendary_icon"}
LOOT_LABELS = {
    "scroll": "Scrolls",
    "body_fragment": "Body fragments",
    "defence_fragment": "Defense fragments",
    "offence_fragment": "Offense fragments",
    "support_fragment": "Support fragments",
    "armor_serum": "Armor serums",
    "female_serum": "Female serums",
    "beast_serum": "Beast serums",
    "colossal_serum": "Colossal serums",
    "vessel": "Vessels",
}
LOOT_MATCH_SCALES = (0.85, 0.95, 1.0, 1.05, 1.15)
LOOT_MATCH_THRESHOLD = 0.75
HOURLY_REPORT_SECONDS = 3600


def _empty_report_counts():
    return {"missions": 0, "completed": 0, "failed": 0, "unknown": 0,
            "timeouts": 0, "mission_seconds": 0.0,
            "loot": {kind: 0 for kind in LOOT_TEMPLATE_FILES},
            "currency": {"gold": 0, "gems": 0,
                         "gold_readings": 0, "gems_readings": 0},
            "perks": {"epic": 0, "legendary": 0, "mythical": 0}}

DEFAULTS = {
    "recording": "",                 # path of the recording to play
    "hotkeys": {"start": "f8", "pause": "f6", "stop": "f7", "record": "f9"},
    "window_pos": None,              # where the app window was last time ([x, y])
    "always_on_top": False,
    "theme": "Midnight Teal",
    "discord_webhook": "",
    "discord_loot_webhook": "",
    "discord_log_webhook": "",
    "hourly_report": True,
    "windowed": False,               # True: the game runs in a window (not fullscreen)
    "window_title": "Roblox",        # title of the game window (used when windowed)
    "capture_monitor": "primary",    # which screen to watch: "primary" (the one at 0,0) or 1, 2, 3...
    "threshold": 0.85,               # template match score needed (0-1)
    "scales": [1.0],                 # e.g. [0.9, 1.0, 1.1] if your window size varies
    "speed": 1.0,                    # playback speed multiplier
    "scan_interval": 0.3,            # seconds between end-screen checks while playing
    "poll_interval": 0.25,           # seconds between checks while waiting
    "wait_for_start": True,          # use the "start" template if you have one
    "load_timeout": 120.0,           # give up waiting for the game to load after this many seconds
    "start_delay": 8.0,              # used when there is no "start" template (skip mode)
    "start_settle": 0.5,             # pause after the start template shows up
    "start_at": 0.0,                 # recording time (s) where the MISSION starts (after the retry
                                     #   clicks + loading). Starts the failsafe timer.
                                     #   0 = use the "start_at" stored in the recording file
    "skip_lead_in": False,           # False: play the recording exactly as recorded (it clicks Retry
                                     #   itself). True: skip everything before start_at and let the
                                     #   app click Retry instead (needs a "start" template)
    "failsafe_after": 90.0,          # failsafe runs this many seconds after the mission starts
    "failsafe_start": 0.0,           # recording time (s) where the failsafe begins; 0 = use the
                                     #   {"type": "failsafe"} marker inside the recording file
    "mission_timeout": 420.0,        # give up waiting for the end screen after this
    "post_end_delay": 0.8,           # pause after the end screen shows, before clicking
    "min_mission_seconds": 10.0,     # an end screen sooner than this after the mission start is not counted
    "retry_jitter": 4,               # random px offset on the retry click
    "abs_offset_x": 0,               # added to recorded absolute mouse positions (if your game
    "abs_offset_y": 0,               #   window sits somewhere else than when you recorded)
}

KEY_ALIASES = {                      # `keyboard` library names -> pydirectinput names
    "left shift": "shiftleft", "right shift": "shiftright", "shift": "shiftleft",
    "left ctrl": "ctrlleft", "right ctrl": "ctrlright", "ctrl": "ctrlleft",
    "left alt": "altleft", "right alt": "altright", "alt": "altleft",
    "left windows": "winleft", "right windows": "winright",
    "ctrl_l": "ctrlleft", "ctrl_r": "ctrlright", "shift_l": "shiftleft", "shift_r": "shiftright",
    "alt_l": "altleft", "alt_r": "altright", "alt_gr": "altright", "caps_lock": "capslock",
    "page_up": "pageup", "page_down": "pagedown", "print_screen": "printscreen",
    "caps lock": "capslock", "escape": "esc", "page up": "pageup",
    "page down": "pagedown", "print screen": "printscreen",
}


def normalize_key(name: str) -> str:
    name = (name or "").lower()
    return KEY_ALIASES.get(name, name)


# --------------------------------------------------------------------------- settings / stats
def _read_json(path, fallback):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return fallback


def _write_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, path)


def load_settings() -> dict:
    s = json.loads(json.dumps(DEFAULTS))
    saved = _read_json(SETTINGS_PATH, {})
    for k, v in saved.items():
        if k == "hotkeys" and isinstance(v, dict):
            s["hotkeys"].update(v)
        elif k in s:
            s[k] = v
    return s


def save_settings(s: dict):
    _write_json(SETTINGS_PATH, s)


EMPTY_STATS = {"missions": 0, "completed": 0, "failed": 0, "unknown": 0,
               "timeouts": 0, "mission_seconds": 0.0}


def load_stats() -> dict:
    s = dict(EMPTY_STATS)
    s.update({k: v for k, v in _read_json(STATS_PATH, {}).items() if k in s})
    return s


def save_stats(s: dict):
    _write_json(STATS_PATH, s)


# --------------------------------------------------------------------------- recordings
def convert_luvmacro(data: dict, failsafe_at: float = 0.0, start_at: float = 0.0) -> dict:
    """Convert a 'luvmacro' recording (mouse_delta / mouse_scroll / ctrl_l ...) to this app's format.
    failsafe_at: recording time (s) where the failsafe part begins (0 = no marker).
    start_at: recording time (s) where the mission actually starts - everything before it (clicking
    Retry, loading) is skipped on playback, because the app clicks Retry itself."""
    events, base, duration = [], 0.0, 0.0
    for step in data["workflow"]["steps"]:
        if step.get("kind") != "recorded_input":
            continue                                   # other step kinds are not supported
        last = 0.0
        for e in step["events"]:
            t = round(base + float(e["t"]), 4)
            last = max(last, float(e["t"]))
            typ = e["type"]
            if typ in ("key_down", "key_up"):
                events.append({"t": t, "type": typ, "key": normalize_key(e["key"])})
            elif typ in ("mouse_down", "mouse_up"):
                ev = {"t": t, "type": typ, "button": e.get("button", "left")}
                if "x" in e and "y" in e:
                    ev.update(x=e["x"], y=e["y"])
                events.append(ev)
            elif typ == "mouse_move":
                events.append({"t": t, "type": "move_abs", "x": e["x"], "y": e["y"]})
            elif typ == "mouse_delta":
                if e.get("dx", 0) or e.get("dy", 0):
                    events.append({"t": t, "type": "move", "dx": e.get("dx", 0), "dy": e.get("dy", 0)})
            elif typ == "mouse_scroll":
                if e.get("dy", 0):
                    events.append({"t": t, "type": "scroll", "dy": e["dy"]})
        base += last
    duration = base
    rec_len = data["workflow"].get("environment", {}).get("recording", {}).get("duration")
    if rec_len:
        duration = max(duration, float(rec_len))
    if failsafe_at > 0:
        events.append({"t": round(float(failsafe_at), 4), "type": "failsafe"})
    events.append({"t": round(duration, 4), "type": "end"})
    events.sort(key=lambda e: e["t"])
    rec = {"version": 1, "source": "luvmacro", "duration": round(duration, 4), "events": events}
    win = (data["workflow"].get("environment", {}).get("recording", {})
           .get("platform", {}).get("window") or {})
    # the game window while recording; absolute click positions are relative to the screen,
    # so the app maps them onto the window the game is in NOW
    rec["ref_window"] = [win.get("x", 0), win.get("y", 0), win.get("width", 1920), win.get("height", 1080)]
    if start_at > 0:
        rec["start_at"] = round(float(start_at), 4)
    return rec


def load_recording(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        rec = json.load(f)
    if rec.get("format") == "luvmacro":                # recordings from the other macro
        rec = convert_luvmacro(rec)
    if not isinstance(rec.get("events"), list) or not rec["events"]:
        raise ValueError("recording has no events")
    return rec


def save_recording(rec: dict, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    _write_json(path, rec)


def expand_events(events: list) -> list:
    """Turn the hand-editable shortcuts into plain events and sort by time.

    Event types in a recording file:
      key_down / key_up   {"t": 1.2, "type": "key_down", "key": "w"}
      tap                 {"t": 1.2, "type": "tap", "key": "q", "hold": 0.03}
      spam                {"t": 1.2, "type": "spam", "key": "q", "duration": 2, "interval": 0.1}
      mouse_down/up       {"t": 1.2, "type": "mouse_down", "button": "left"}
      move                {"t": 1.2, "type": "move", "dx": 0, "dy": 300}   (relative, raw input)
      move_abs            {"t": 0.0, "type": "move_abs", "x": 970, "y": 552}  (absolute screen position)
      scroll              {"t": 22.2, "type": "scroll", "dy": -120}        (mouse wheel, 120 = 1 notch)
      (mouse_down / mouse_up may also carry "x" and "y": the cursor jumps there first)
      failsafe            {"t": 62.0, "type": "failsafe"}  (everything after this is the failsafe;
                          it only runs if the end screen has not shown up after `failsafe_after` s)
      end                 {"t": 30.0, "type": "end"}    (marks where the recording ends)
    """
    out = []
    for ev in events:
        if ev.get("type") == "spam":
            t = float(ev["t"])
            stop = t + float(ev.get("duration", 1.0))
            gap = max(0.02, float(ev.get("interval", 0.1)))
            while t < stop:
                out.append({"t": round(t, 4), "type": "tap", "key": ev["key"]})
                t += gap
        else:
            out.append(ev)
    out.sort(key=lambda e: float(e["t"]))
    return out


class Recorder:
    """Records keys, mouse buttons and mouse movement (as relative deltas)."""

    def __init__(self, ignore_keys=()):
        self.ignore = {normalize_key(k) for k in ignore_keys}
        self.active = False

    def start(self):
        import keyboard
        import mouse
        self._kb, self._ms = keyboard, mouse
        self.events, self.t0 = [], None
        self.held, self.last_pos = set(), None
        self.pending, self.last_flush = [0, 0], 0.0
        self.lock = threading.Lock()
        self._kb_hook = keyboard.hook(self._on_key)
        self._ms_hook = mouse.hook(self._on_mouse)
        self.active = True

    def _now(self):
        n = time.perf_counter()
        if self.t0 is None:
            self.t0 = n
        return n - self.t0

    def _flush_move(self, t):
        if self.pending != [0, 0]:
            self.events.append({"t": round(t, 4), "type": "move",
                                "dx": self.pending[0], "dy": self.pending[1]})
            self.pending = [0, 0]
            self.last_flush = t

    def _on_key(self, e):
        name = normalize_key(e.name)
        if name in self.ignore:
            return
        with self.lock:
            if e.event_type == "down":
                if name in self.held:          # ignore the OS auto-repeat
                    return
                self.held.add(name)
                typ = "key_down"
            else:
                self.held.discard(name)
                typ = "key_up"
            t = self._now()
            self._flush_move(t)
            self.events.append({"t": round(t, 4), "type": typ, "key": name})

    def _on_mouse(self, e):
        kind = type(e).__name__
        with self.lock:
            if kind == "MoveEvent":
                if self.last_pos is not None:
                    self.pending[0] += int(e.x - self.last_pos[0])
                    self.pending[1] += int(e.y - self.last_pos[1])
                self.last_pos = (e.x, e.y)
                t = self._now()
                if t - self.last_flush >= 0.02:
                    self._flush_move(t)
            elif kind == "ButtonEvent" and e.button in ("left", "right", "middle"):
                t = self._now()
                self._flush_move(t)
                typ = "mouse_up" if e.event_type == "up" else "mouse_down"
                self.events.append({"t": round(t, 4), "type": typ, "button": e.button})

    def stop(self) -> dict:
        self._kb.unhook(self._kb_hook)
        self._ms.unhook(self._ms_hook)
        self.active = False
        with self.lock:
            t = self._now()
            self._flush_move(t)
            self.events.append({"t": round(t, 4), "type": "end"})
        return {"version": 1, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
                "duration": round(t, 4), "events": self.events}


# --------------------------------------------------------------------------- input backend
class Keys:
    """Sends real input through pydirectinput (works in games that ignore normal input)."""

    def __init__(self):
        import pydirectinput as pdi
        pdi.PAUSE = 0
        self.pdi = pdi

    def down(self, key): self.pdi.keyDown(key)
    def up(self, key): self.pdi.keyUp(key)
    def mouse_down(self, button): self.pdi.mouseDown(button=button)
    def mouse_up(self, button): self.pdi.mouseUp(button=button)
    def move_rel(self, dx, dy): self.pdi.moveRel(dx, dy, relative=True)
    def move_abs(self, x, y): self.pdi.moveTo(int(x), int(y))
    def position(self): return self.pdi.position()

    def scroll(self, dy):
        """Mouse wheel. dy is in Windows wheel units (120 = one notch, negative = towards you)."""
        if sys.platform != "win32":
            return
        import ctypes
        fn = ctypes.windll.user32.mouse_event
        fn.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_size_t]
        fn(0x0800, 0, 0, int(dy) & 0xFFFFFFFF, 0)          # MOUSEEVENTF_WHEEL

    def click_abs(self, x, y):
        self.pdi.moveTo(int(x), int(y))
        time.sleep(0.06)
        self.pdi.mouseDown()
        time.sleep(0.05)
        self.pdi.mouseUp()


class Stopped(Exception):
    """Raised inside the worker when the user presses stop."""


class MissionEnded(Exception):
    """Raised during playback when the end screen shows up."""

    def __init__(self, info):
        super().__init__("mission ended")
        self.info = info


class Player:
    def __init__(self, io, offset=(0, 0), mapper=None, clamp=None):
        self.io = io
        self.offset = (int(offset[0]), int(offset[1]))
        self.mapper = mapper                     # (x, y) recorded -> (x, y) on this screen
        self.clamp = clamp
        self.keys, self.buttons = set(), set()
        self.on_key = None                       # optional callback(key) for logging

    def play(self, rec, speed, checkpoint, tick, tick_every,
             failsafe_after=0.0, failsafe_start=0.0, on_failsafe=None, start_at=0.0,
             skip_lead_in=False, stop_at=None):
        """checkpoint() -> seconds spent paused (raises Stopped); tick() may raise MissionEnded.

        stop_at: play only the events before this recording time (used for the retry clicks that
        come before the game has loaded).

        start_at: recording time where the mission starts. skip_lead_in=False plays the whole
        recording (the retry clicks and loading included); True drops everything before start_at.

        Failsafe: once every event before the "failsafe" marker has played, the player holds until
        `failsafe_after` seconds have passed since the MISSION started (still calling tick() so the
        end screen can abort it), then runs the failsafe part. The recorded gap between the last
        mission event and the marker is skipped. failsafe_after = 0 -> use the marker's own time."""
        raw = list(rec["events"])
        if failsafe_start > 0 and not any(e.get("type") == "failsafe" for e in raw):
            raw.insert(0, {"t": float(failsafe_start), "type": "failsafe"})
        events = expand_events(raw)
        if stop_at is not None:
            events = [e for e in events if float(e["t"]) < stop_at]
            if not events:
                return
        elif not any(e.get("type") == "end" for e in events):
            events.append({"t": float(rec.get("duration", events[-1]["t"])), "type": "end"})
            events.sort(key=lambda e: float(e["t"]))
        trim = skip_lead_in and start_at > 0
        if trim:                                 # drop the lead-in, then the clock starts at 0
            events = [dict(e, t=round(float(e["t"]) - start_at, 4))
                      for e in events if float(e["t"]) >= start_at]
        speed = max(0.1, float(speed))
        start = time.perf_counter()
        begin = start + (0.0 if trim else max(0.0, float(start_at)) / speed)   # mission clock
        last_tick = start
        try:
            for ev in events:
                target = float(ev["t"]) / speed
                is_failsafe = ev.get("type") == "failsafe"
                while True:
                    paused = checkpoint()
                    start += paused
                    begin += paused
                    now = time.perf_counter()
                    if now - last_tick >= tick_every:
                        tick()
                        last_tick = time.perf_counter()
                        now = last_tick
                    remaining = start + target - now
                    if is_failsafe and failsafe_after > 0:
                        remaining = begin + failsafe_after - now
                    if remaining <= 0:
                        break
                    time.sleep(min(remaining, 0.01))
                if is_failsafe:
                    start = time.perf_counter() - target     # events after it keep their spacing
                    if on_failsafe:
                        on_failsafe()
                self._fire(ev)
        finally:
            self.release_all()

    def _fire(self, ev):
        kind = ev.get("type")
        if kind in ("key_down", "tap") and self.on_key:
            self.on_key(ev["key"])
        if kind == "key_down":
            self.io.down(ev["key"]); self.keys.add(ev["key"])
        elif kind == "key_up":
            self.io.up(ev["key"]); self.keys.discard(ev["key"])
        elif kind == "tap":
            self.io.down(ev["key"]); time.sleep(float(ev.get("hold", 0.03))); self.io.up(ev["key"])
        elif kind == "mouse_down":
            self._goto(ev)
            self.io.mouse_down(ev.get("button", "left")); self.buttons.add(ev.get("button", "left"))
        elif kind == "mouse_up":
            self._goto(ev)
            self.io.mouse_up(ev.get("button", "left")); self.buttons.discard(ev.get("button", "left"))
        elif kind == "move_abs":
            self._goto(ev)
        elif kind == "scroll":
            self.io.scroll(int(ev["dy"]))
        elif kind in ("move", "move_raw"):
            # Preserve the recording's relative movement deltas (camera motion depends on them).
            self.io.move_rel(int(ev["dx"]), int(ev["dy"]))
        # "end" and unknown types do nothing

    def _goto(self, ev):
        if "x" in ev and "y" in ev:
            if self.mapper:
                x, y = self.mapper(ev["x"], ev["y"])
            else:
                x, y = int(ev["x"]) + self.offset[0], int(ev["y"]) + self.offset[1]
            if self.clamp:
                x, y = self.clamp(int(x), int(y))
            self.io.move_abs(int(x), int(y))

    def release_all(self):
        for k in list(self.keys):
            try: self.io.up(k)
            except Exception: pass
        for b in list(self.buttons):
            try: self.io.mouse_up(b)
            except Exception: pass
        self.keys.clear(); self.buttons.clear()


# --------------------------------------------------------------------------- game window
class GameWindowNotFound(RuntimeError):
    pass


def find_window_rect(title="Roblox"):
    """(left, top, width, height) of the game window's picture (without title bar / borders), in
    screen pixels - or None if there is no visible window with that exact title."""
    if sys.platform != "win32":
        return None
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    wanted = (title or "Roblox").strip().lower()
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def visit(hwnd, _):
        if user32.IsWindowVisible(hwnd) and not user32.IsIconic(hwnd):
            n = user32.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(hwnd, buf, n + 1)
                if buf.value.strip().lower() == wanted:
                    rect, pt = wintypes.RECT(), wintypes.POINT(0, 0)
                    user32.GetClientRect(hwnd, ctypes.byref(rect))
                    user32.ClientToScreen(hwnd, ctypes.byref(pt))
                    w, h = rect.right - rect.left, rect.bottom - rect.top
                    if w >= 200 and h >= 150:
                        found.append((pt.x, pt.y, w, h))
        return True

    user32.EnumWindows(visit, 0)
    return max(found, key=lambda r: r[2] * r[3]) if found else None


# --------------------------------------------------------------------------- vision
Match = namedtuple("Match", "score x y w h")


class Vision:
    def __init__(self, settings):
        self.s = settings
        self.sct = None
        self.cache = {}
        self.last_score = {}                 # best match score per template from the latest find()
        self.ref_h = {}                      # name -> height of the screen the template was captured at

    def open(self):
        import mss
        self.sct = mss.mss()                 # mss handles are per-thread: open inside the worker

    def close(self):
        if self.sct is not None:
            self.sct.close()
            self.sct = None

    def monitor(self):
        """The screen to watch. "primary" = the one whose top-left corner is (0, 0) - that is the
        main screen in Windows, and where the recording's click positions come from. (mss' own
        numbering depends on how Windows lists the screens, so we do not rely on it.)"""
        mons = self.sct.monitors
        choice = self.s.get("capture_monitor", "primary")
        if str(choice).lower() == "primary":
            for m in mons[1:]:
                if m["left"] == 0 and m["top"] == 0:
                    return m
            return mons[1] if len(mons) > 1 else mons[0]
        return mons[min(max(1, int(choice)), len(mons) - 1)]

    def region(self):
        """The part of the screen the game is in: the game window (windowed mode) or the screen."""
        if self.s.get("windowed"):
            r = find_window_rect(self.s.get("window_title", "Roblox"))
            if r is None:
                raise GameWindowNotFound(
                    f"Could not find the game window titled '{self.s.get('window_title', 'Roblox')}' - "
                    "is the game open (and not minimized)? Use 'Check window' in the settings.")
            return {"left": r[0], "top": r[1], "width": r[2], "height": r[3]}
        return self.monitor()

    def grab(self):
        """-> (BGR frame, region dict). Match coordinates are relative to the region."""
        mon = self.region()
        shot = self.sct.grab(mon)
        return np.ascontiguousarray(np.asarray(shot)[:, :, :3]), mon

    def template(self, name):
        path = os.path.join(TEMPLATE_DIR, name + ".png")
        if not os.path.exists(path):
            return None
        mtime = os.path.getmtime(path)
        hit = self.cache.get(name)
        if hit and hit[0] == mtime:
            return hit[1]
        img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
        self.cache[name] = (mtime, img)
        side = _read_json(os.path.join(TEMPLATE_DIR, name + ".json"), {})   # written by the capture tool
        self.ref_h[name] = float(side["ref_h"]) if side.get("ref_h") else None
        return img

    def base_scale(self, name, frame):
        """Templates captured with the app's tool remember the screen height they were captured at,
        so they still match when the game window is a different size now."""
        rh = self.ref_h.get(name)
        if not rh:
            return 1.0
        k = frame.shape[0] / rh
        return 1.0 if abs(k - 1.0) < 0.01 else k

    def find_scaled(self, frame, name, threshold, scales, region=None):
        tpl = self.template(name)
        if tpl is None:
            return None
        if region is None:
            x0, y0 = 0, 0
            search = frame
        else:
            x0, y0, x1, y1 = (int(v) for v in region)
            h, w = frame.shape[:2]
            x0, x1 = max(0, x0), min(w, x1)
            y0, y1 = max(0, y0), min(h, y1)
            if x1 <= x0 or y1 <= y0:
                return None
            search = frame[y0:y1, x0:x1]
        best = None
        base = self.base_scale(name, frame)
        for sc in scales:
            k = sc * base
            t = tpl if k == 1.0 else cv2.resize(
                tpl, None, fx=k, fy=k,
                interpolation=cv2.INTER_AREA if k < 1 else cv2.INTER_LINEAR)
            th, tw = t.shape[:2]
            if th < 4 or tw < 4 or th > search.shape[0] or tw > search.shape[1]:
                continue
            res = cv2.matchTemplate(search, t, cv2.TM_CCOEFF_NORMED)
            _, score, _, loc = cv2.minMaxLoc(res)
            score = float(score) if score == score else 0.0      # NaN on flat templates
            if best is None or score > best.score:
                best = Match(score, x0 + loc[0] + tw // 2,
                             y0 + loc[1] + th // 2, tw, th)
        self.last_score[name] = best.score if best else 0.0
        return best if best and best.score >= float(threshold) else None

    def find(self, frame, name):
        return self.find_scaled(frame, name, self.s["threshold"], self.s["scales"])


def capture_area(settings) -> dict:
    """The region (left, top, width, height) the macro watches - the game window or the screen."""
    v = Vision(settings)
    v.open()
    try:
        return v.region()
    finally:
        v.close()


def diagnose_screen(settings) -> dict:
    """Grab the screen exactly like the macro does and report how well each template matches.
    Saves debug/screen.png (what the macro sees, with the matches boxed) for a look by eye."""
    v = Vision(settings)
    v.open()
    try:
        frame, mon = v.grab()
    finally:
        v.close()
    scales = [round(0.70 + 0.05 * i, 2) for i in range(13)]            # 0.70 ... 1.30
    out = {"monitor": mon, "brightness": float(frame.mean()), "templates": [], "files": []}
    shown = frame.copy()
    for name in TEMPLATES:
        tpl = v.template(name)
        if tpl is None:
            out["templates"].append({"name": name, "exists": False})
            continue
        best = None                                                     # (score, scale, x, y, w, h)
        at_one = 0.0
        base = v.base_scale(name, frame)
        for sc in scales:
            k = sc * base
            t = tpl if k == 1.0 else cv2.resize(tpl, None, fx=k, fy=k, interpolation=cv2.INTER_AREA if k < 1 else cv2.INTER_LINEAR)
            th, tw = t.shape[:2]
            if th < 4 or tw < 4 or th > frame.shape[0] or tw > frame.shape[1]:
                continue
            _, score, _, loc = cv2.minMaxLoc(cv2.matchTemplate(frame, t, cv2.TM_CCOEFF_NORMED))
            score = float(score) if score == score else 0.0
            if sc == 1.0:
                at_one = score
            if best is None or score > best[0]:
                best = (score, sc, loc[0], loc[1], tw, th)
        found = at_one >= settings["threshold"]
        out["templates"].append({"name": name, "exists": True, "score": at_one, "found": found,
                                 "best_score": best[0], "best_scale": best[1],
                                 "pos": (best[2] + best[4] // 2, best[3] + best[5] // 2),
                                 "size": tpl.shape[1::-1]})
        color = (0, 200, 0) if found else (0, 0, 255)
        cv2.rectangle(shown, (best[2], best[3]), (best[2] + best[4], best[3] + best[5]), color, 3)
        cv2.putText(shown, f"{name} {best[0]:.2f}", (best[2], max(20, best[3] - 8)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)
    os.makedirs(DEBUG_DIR, exist_ok=True)
    for fname, img in (("screen_raw.png", frame), ("screen.png", shown)):
        path = os.path.join(DEBUG_DIR, fname)
        cv2.imencode(".png", img)[1].tofile(path)
        out["files"].append(path)
    return out


# --------------------------------------------------------------------------- the mission loop
class Runner:
    """Runs the loop in a background thread and reports to the GUI through `emit`."""

    def __init__(self, settings, recording, stats, emit, make_io=Keys):
        self.s, self.rec, self.stats, self.emit = settings, recording, stats, emit
        self.make_io = make_io
        self.stop_ev, self.pause_ev = threading.Event(), threading.Event()
        self.thread = None
        self.runtime_started = None
        self.status = ""
        self.found_end = None
        self.last_scores = {}
        self.seen_gone = False
        self._region, self._region_t = None, 0.0
        self.hourly_report_stop = threading.Event()
        self.report_lock = threading.Lock()
        self.report_total = _empty_report_counts()
        self.report_interval = _empty_report_counts()
        self.report_interval_started = None
        self.latest_completion_png = None
        self.last_result = None
        self.report_thread = None
        self.currency_ocr_warned = False
        self.report_jobs_lock = threading.Lock()
        self.report_jobs = set()

    # ---- control (called from the GUI thread)
    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_ev.set()
        self.hourly_report_stop.set()

    def toggle_pause(self) -> bool:
        if self.pause_ev.is_set():
            self.pause_ev.clear()
        else:
            self.pause_ev.set()
        return self.pause_ev.is_set()

    @property
    def alive(self):
        return self.thread is not None and self.thread.is_alive()

    # ---- helpers
    def log(self, msg): self.emit("log", msg)

    def set_status(self, text):
        self.status = text
        self.emit("status", text)

    def checkpoint(self) -> float:
        """Stop / pause handling. Returns how long we were paused."""
        if self.stop_ev.is_set():
            raise Stopped
        if not self.pause_ev.is_set():
            return 0.0
        before, t0 = self.status, time.perf_counter()
        self.set_status("Paused")
        while self.pause_ev.is_set():
            if self.stop_ev.is_set():
                raise Stopped
            time.sleep(0.05)
        self.set_status(before)
        return time.perf_counter() - t0

    def sleep(self, secs):
        end = time.perf_counter() + secs
        while True:
            self.checkpoint()
            rem = end - time.perf_counter()
            if rem <= 0:
                return
            time.sleep(min(rem, 0.05))

    def map_abs(self, x, y):
        """Recorded screen position -> position on the game window / screen right now. The recording
        remembers the window it was made in (e.g. 1920x1080 at 0,0); positions are scaled
        proportionally, so they work in a window of any size, anywhere on the screen."""
        now = time.perf_counter()
        if self._region is None or now - self._region_t > 0.5:      # the window may be moved
            self._region, self._region_t = self.vision.region(), now
        r = self._region
        rx, ry, rw, rh = self.rec.get("ref_window") or (0, 0, 1920, 1080)
        X = r["left"] + (float(x) - rx) * r["width"] / float(rw)
        Y = r["top"] + (float(y) - ry) * r["height"] / float(rh)
        return round(X) + int(self.s["abs_offset_x"]), round(Y) + int(self.s["abs_offset_y"])

    def clamp_cursor(self, x, y):
        """Keep replayed mouse movement within the game capture region."""
        r = self._region if self._region is not None else self.vision.region()
        return (min(max(int(x), int(r["left"])), int(r["left"] + r["width"] - 1)),
                min(max(int(y), int(r["top"])), int(r["top"] + r["height"] - 1)))

    def log_key(self, key):
        """Log a key when it differs from the last one (or after a pause) so bursts show once."""
        now = time.perf_counter()
        if key == "ctrlleft":
            self.log("  key ctrlleft (Shift Lock toggle)")
            self._last_key, self._last_key_t = key, now
            return
        if key != self._last_key or now - self._last_key_t > 1.5:
            self.log(f"  key {key}")
        self._last_key, self._last_key_t = key, now

    # ---- detection
    def detect_end(self, frame, mon, vision=None):
        """The mission is over when ANY of these is on screen: the Retry button, the 'completed'
        banner or the 'failed' banner. info["retry"] is None if only a banner is visible (yet)."""
        vision = vision or self.vision
        retry = vision.find(frame, "retry")
        result = "unknown"
        if vision.find(frame, "result_completed"):
            result = "completed"
        elif vision.find(frame, "result_failed"):
            result = "failed"
        if not retry and result == "unknown":
            return None
        return {"retry": retry, "result": result, "mon": mon}

    def detect_retry(self, frame, mon, vision=None):
        """Like detect_end, but only when the Retry button itself is visible (it can be clicked)."""
        info = self.detect_end(frame, mon, vision)
        return info if info and info["retry"] else None

    def wait_for_retry(self, timeout=90.0):
        """A banner is showing but the Retry button is not there yet: wait for it."""
        t0 = time.time()
        self.set_status("Waiting for the Retry button")
        while time.time() - t0 < timeout:
            self.checkpoint()
            frame, mon = self.vision.grab()
            info = self.detect_retry(frame, mon)
            if info:
                return info
            self.sleep(self.s["poll_interval"])
        return None

    def tick(self):
        """Called often by the player; cheap. The screen is checked by the scanner thread."""
        if self.found_end:
            raise MissionEnded(self.found_end)

    def _scan_loop(self, stop):
        """Background thread: watches for the end screen so playback timing is never disturbed.
        (mss handles belong to one thread, so this thread opens its own.)"""
        vision = Vision(self.s)
        try:
            vision.open()
            while not stop.is_set():
                t0 = time.perf_counter()
                if not self.pause_ev.is_set():
                    frame, mon = vision.grab()
                    info = self.detect_end(frame, mon, vision)
                    self.last_scores = dict(vision.last_score)
                    if info is None:
                        self.seen_gone = True        # retry button gone: the mission is under way
                    elif self.seen_gone:             # (else: still the end screen the recording clicks through)
                        self.found_end = info
                        return
                stop.wait(max(0.0, float(self.s["scan_interval"]) - (time.perf_counter() - t0)))
        except Exception as exc:                     # never let the scanner die silently
            self.log(f"Screen scanner error: {type(exc).__name__}: {exc}")
        finally:
            vision.close()

    # ---- the loop
    def _run(self):
        self.vision = None
        failure = None
        try:
            self.vision = Vision(self.s)
            self.set_status("Starting screen capture")
            self.log("Initializing screen capture")
            self.vision.open()
            self.checkpoint()
            self.log("Screen capture ready; initializing input")
            self.io = self.make_io()
            self.checkpoint()
            self.player = Player(self.io, (self.s["abs_offset_x"], self.s["abs_offset_y"]),
                                 mapper=self.map_abs, clamp=self.clamp_cursor)
            self.player.on_key = self.log_key
            self._last_key, self._last_key_t = None, 0.0
            self.log("Macro started")
            self.runtime_started = time.monotonic()
            self._start_hourly_reporter()
            self.set_status("Reading screen")
            _, mon = self.vision.grab()
            self.checkpoint()
            what = "Game window" if self.s["windowed"] else "Watching the screen"
            self.log(f"{what}: {mon['width']}x{mon['height']} at ({mon['left']}, {mon['top']})")
            rx, ry, rw, rh = self.rec.get("ref_window") or (0, 0, 1920, 1080)
            if (mon["width"], mon["height"]) != (rw, rh):
                self.log(f"The recording was made at {rw}x{rh}; its click positions are scaled to "
                         f"{mon['width']}x{mon['height']}")
                if abs(mon["width"] / mon["height"] - rw / rh) > 0.05:
                    self.log("Note: the shape of this window differs from the recording's. If the Retry "
                             "clicks miss, tick 'Skip the recording's start' (the app then clicks Retry "
                             "using the picture of the button).")
            while True:
                self.checkpoint()
                if self.s["skip_lead_in"]:
                    self.wait_for_start()
                else:
                    self.wait_for_end_screen()
                self.run_mission()
        except Stopped:
            self.log("Macro stopped")
        except Exception as exc:                       # includes pydirectinput's FailSafeException
            failure = f"{type(exc).__name__}: {exc}"
            self.log(f"ERROR: {type(exc).__name__}: {exc}")
            self.log(traceback.format_exc(limit=3))
            self.emit("fatal", failure)
        finally:
            self.hourly_report_stop.set()
            self._queue_session_report()
            try: self.player.release_all()
            except Exception: pass
            try:
                if self.vision is not None:
                    self.vision.close()
            except Exception as exc:
                try:
                    self.log(f"Screen capture cleanup error: {type(exc).__name__}: {exc}")
                except Exception:
                    pass
            finally:
                try:
                    self.set_status("Error" if failure else "Stopped")
                finally:
                    self.emit("finished", None)

    def wait_for_end_screen(self):
        """The recording starts on the end screen (it clicks Retry itself), so wait for it."""
        self.set_status("Waiting for the end screen")
        self.log("Waiting for the Retry screen before playback")
        shown = False
        while True:
            self.checkpoint()
            frame, mon = self.vision.grab()
            info = self.detect_end(frame, mon)
            if info and info["retry"]:
                return
            if info and not shown:                   # banner visible, Retry button not yet
                self.log("Mission over - waiting for the Retry button")
                shown = True
            if not shown:
                self.set_status("Waiting for the end screen")
                self.log("Waiting for the end screen (the recording starts by clicking Retry)")
                shown = True
            self.sleep(self.s["poll_interval"])

    def click_retry_if_visible(self):
        """If the end screen is showing (e.g. you pressed Start there), click Retry now."""
        frame, mon = self.vision.grab()
        info = self.detect_retry(frame, mon)
        if info:
            self.log("End screen is showing - clicking retry")
            self.click_retry(info)

    def wait_for_start(self):
        s = self.s
        self.click_retry_if_visible()
        if s["wait_for_start"] and self.vision.template("start") is not None:
            self.set_status("Waiting for mission start")
            while True:
                self.checkpoint()
                frame, mon = self.vision.grab()
                if self.vision.find(frame, "start"):
                    break
                info = self.detect_retry(frame, mon)
                if info:
                    self.click_retry(info)
                self.sleep(s["poll_interval"])
            self.sleep(s["start_settle"])
        else:
            self.set_status(f"Waiting {s['start_delay']:g}s for the mission to load")
            self.sleep(s["start_delay"])

    def mission_start_at(self):
        return self.s["start_at"] or float(self.rec.get("start_at", 0) or 0)

    def wait_until_loaded(self):
        """After the retry clicks: wait until the 'start' template (in-game HUD) is visible.
        It only counts once the Retry button has been seen gone, so the end screen / loading
        screen can not be mistaken for the game. Returns False on timeout."""
        s = self.s
        self.set_status("Waiting for the game to load")
        t0 = time.time()
        retry_gone, retry_since = False, None
        while time.time() - t0 < float(s["load_timeout"]):
            self.checkpoint()
            frame, mon = self.vision.grab()
            info = self.detect_retry(frame, mon)
            if info is None:
                retry_gone, retry_since = True, None
                if self.vision.find(frame, "start"):
                    self.log(f"Game loaded ({time.time() - t0:.0f}s after the retry clicks)")
                    return True
            elif not retry_gone:                      # retry still showing: did the click miss?
                retry_since = retry_since or time.time()
                if time.time() - retry_since > 4.0:
                    self.log("Retry button still showing - clicking it")
                    self.click_retry(info)
                    retry_since = None
            self.sleep(s["poll_interval"])
        self.log(f"The game did not load within {s['load_timeout']:g}s")
        return False

    def _failsafe_started(self):
        sc = ", ".join(f"{k} {v:.2f}" for k, v in sorted(self.last_scores.items())) or "no scan yet"
        self.log(f"No end screen seen - running the failsafe (latest match scores: {sc}; "
                 f"{float(self.s['threshold']):.2f} is needed)")

    def run_mission(self):
        s, st = self.s, self.stats
        start_at = self.mission_start_at()
        # The recording starts on the end screen. With a 'start' template we play only its retry
        # clicks, wait until the game has really loaded, then play the rest ("loaded mode").
        loaded_mode = (not s["skip_lead_in"] and start_at > 0
                       and self.vision.template("start") is not None)
        if loaded_mode:
            self.set_status("Clicking retry")
            self.log("Retrying (the recording clicks Retry)")
            self.player.play(self.rec, s["speed"], self.checkpoint, lambda: None, 0.2,
                             start_at=start_at, stop_at=start_at)
            if not self.wait_until_loaded():
                return
            self.sleep(s["start_settle"])
        elif not s["skip_lead_in"] and self.vision.template("start") is None:
            self.log("No 'start' template: using the recorded loading time (capture one to wait "
                     "for the game to load)")
        trim = loaded_mode or s["skip_lead_in"]
        t0 = time.time()
        self.seen_gone = trim                        # retry already clicked and gone
        self.found_end = None
        self.log(f"Mission {st['missions'] + 1} started")
        self.set_status("Running recording")
        info = None
        scan_stop = threading.Event()
        scanner = threading.Thread(target=self._scan_loop, args=(scan_stop,), daemon=True)
        scanner.start()
        try:
            self.player.play(
                self.rec, s["speed"], self.checkpoint, self.tick, 0.02,
                failsafe_after=s["failsafe_after"], failsafe_start=s["failsafe_start"],
                on_failsafe=self._failsafe_started, start_at=start_at, skip_lead_in=trim)
        except MissionEnded as e:
            info = e.info
        finally:
            scan_stop.set()
            scanner.join(2.0)
        if info is None:
            self.set_status("Waiting for end screen")
            info = self.wait_for_end(t0 + s["mission_timeout"])
        # mission length = time since the mission started (not since the recording started)
        lead = 0.0 if trim else start_at / max(0.1, float(s["speed"]))
        seconds = max(0.0, time.time() - t0 - lead)
        if info is None:
            st["missions"] += 1
            st["timeouts"] += 1
            self._record_report_result("timeouts", seconds, {kind: 0 for kind in LOOT_TEMPLATE_FILES}, None, {}, {})
            self.log("Timed out waiting for the end screen")
            self.finish_stats()
            return
        self.finish_mission(info, seconds)

    def wait_for_end(self, deadline):
        while time.time() < deadline:
            self.checkpoint()
            frame, mon = self.vision.grab()
            info = self.detect_end(frame, mon)
            if info:
                return info
            self.sleep(self.s["poll_interval"])
        return None

    def finish_stats(self):
        save_stats(self.stats)
        self.emit("stats", dict(self.stats))

    def finish_mission(self, info, seconds):
        st = self.stats
        self.sleep(self.s["post_end_delay"])             # result text can show a moment late
        frame, mon = self.vision.grab()
        fresh = self.detect_end(frame, mon)
        if fresh:                                         # newest look at the screen wins,
            fresh["retry"] = fresh["retry"] or info["retry"]  # but keep a known Retry position
            info = fresh
        result = info["result"]
        counted = seconds >= float(self.s["min_mission_seconds"])
        if not counted:
            self.log(f"End screen only {seconds:.0f}s after the mission started - not counted")
        else:
            st["missions"] += 1
            st[result] += 1
            st["mission_seconds"] += seconds
            self.log(f"Mission {st['missions']}: {result} ({seconds:.0f}s)")
            self.finish_stats()
            if result == "completed":
                self._queue_report_enrichment(result, seconds, frame)
                loot_webhook = (self.s.get("discord_loot_webhook") or
                                self.s.get("discord_webhook", "")).strip()
                if loot_webhook:
                    elapsed = (time.monotonic() - self.runtime_started
                               if self.runtime_started is not None else 0)
                    sender = threading.Thread(
                        target=self.send_completion_screenshot,
                        args=(frame, dict(st), elapsed),
                        name="mission-screenshot-webhook", daemon=True)
                    sender.start()
            else:
                self._record_report_result(result, seconds, {kind: 0 for kind in LOOT_TEMPLATE_FILES}, None, {}, {})
        if self.s["skip_lead_in"]:
            self.click_retry(info)       # otherwise the recording clicks Retry itself next round

    def _result_anchor(self, frame):
        banner = self.vision.find(frame, "result_completed")
        template = self.vision.template("result_completed")
        if not banner or template is None or template.shape[1] <= 0:
            return None
        scale = banner.w / float(template.shape[1])
        if not 0.5 <= scale <= 2.0:
            return None
        return banner.x, banner.y, scale

    def _reward_search_region(self, frame, anchor):
        h, w = frame.shape[:2]
        if anchor:
            x, y, scale = anchor
            return (max(0, x - round(450 * scale)),
                    max(0, y + round(330 * scale)),
                    min(w, x + round(450 * scale)),
                    min(h, y + round(450 * scale)))
        return (round(w * 0.28), round(h * 0.48),
                round(w * 0.72), round(h * 0.78))

    def _find_reward_cards(self, frame, anchor):
        if not anchor:
            return []
        x0, y0, x1, y1 = self._reward_search_region(frame, anchor)
        region = frame[y0:y1, x0:x1]
        if region.size == 0:
            return []
        hsv = cv2.cvtColor(region, cv2.COLOR_BGR2HSV)
        border_mask = cv2.inRange(hsv, (8, 100, 140), (40, 255, 255))
        contours, _ = cv2.findContours(border_mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        scale = anchor[2]
        min_side, max_side = round(45 * scale), round(105 * scale)
        candidates = []
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            if (min_side <= w <= max_side and min_side <= h <= max_side
                    and 0.75 <= w / max(1.0, h) <= 1.3):
                candidates.append((x0 + x, y0 + y, w, h))
        # The gold frame produces nested inner and outer contours. Keep one box per card.
        cards = []
        for box in sorted(candidates, key=lambda b: b[2] * b[3], reverse=True):
            x, y, w, h = box
            cx, cy = x + w / 2, y + h / 2
            if any(abs(cx - (a + aw / 2)) < 14 * scale and
                   abs(cy - (b + ah / 2)) < 14 * scale for a, b, aw, ah in cards):
                continue
            cards.append(box)
        return sorted(cards, key=lambda box: box[0])

    def _card_icon_region(self, frame, card):
        x, y, w, h = card
        return frame[y + max(2, round(h * 0.04)):y + round(h * 0.76),
                     x + max(2, round(w * 0.05)):x + w - max(2, round(w * 0.05))]

    def _best_card_icon(self, icon_region, template_name, card_scale=1.0):
        template = self.vision.template(template_name)
        if template is None or icon_region.size == 0:
            return 0.0
        ih, iw = icon_region.shape[:2]
        th, tw = template.shape[:2]
        max_scale = min((iw - 2) / max(1, tw), (ih - 2) / max(1, th))
        if max_scale <= 0:
            return 0.0
        best = 0.0
        for portion in (0.50, 0.60, 0.70, 0.80, 0.90, 1.0):
            factor = max_scale * portion
            icon = cv2.resize(template, None, fx=factor, fy=factor,
                              interpolation=cv2.INTER_AREA if factor < 1 else cv2.INTER_CUBIC)
            if icon.shape[0] > ih or icon.shape[1] > iw:
                continue
            score = cv2.minMaxLoc(cv2.matchTemplate(
                icon_region, icon, cv2.TM_CCOEFF_NORMED))[1]
            best = max(best, float(score))
        return best

    def _red_mythic_marker(self, icon_region):
        if icon_region.size == 0:
            return False
        hsv = cv2.cvtColor(icon_region, cv2.COLOR_BGR2HSV)
        red = (((hsv[:, :, 0] <= 8) | (hsv[:, :, 0] >= 170)) &
               (hsv[:, :, 1] >= 135) & (hsv[:, :, 2] >= 90))
        return int(np.count_nonzero(red)) >= max(18, int(red.size * 0.055))

    def _analyze_reward_cards(self, frame, cards):
        loot_found = {kind: 0 for kind in LOOT_TEMPLATE_FILES}
        perks = {"epic": 0, "legendary": 0, "mythical": 0}
        currencies = {}
        for card in cards:
            x, y, w, h = card
            icon_region = self._card_icon_region(frame, card)
            gold_score = self._best_card_icon(icon_region, CURRENCY_GOLD_ICON)
            if gold_score >= 0.78:
                currencies["gold"] = card
                continue
            gem_score = self._best_card_icon(icon_region, CURRENCY_GEM_ICON)
            if gem_score >= 0.78:
                currencies["gems"] = card
                continue
            epic_score = self._best_card_icon(icon_region, PERK_ICON_TEMPLATES["epic"])
            if epic_score >= 0.78:
                perks["epic"] += 1
                continue
            legendary_score = self._best_card_icon(icon_region, PERK_ICON_TEMPLATES["legendary"])
            if legendary_score >= 0.78:
                perks["legendary"] += 1
                continue
            loot_scores = [(self._best_card_icon(icon_region, template), kind)
                           for kind, template in LOOT_TEMPLATE_FILES.items()]
            best_score, best_kind = max(loot_scores, default=(0.0, None))
            if best_kind is not None and best_score >= LOOT_MATCH_THRESHOLD:
                loot_found[best_kind] += 1
                continue
            if self._red_mythic_marker(icon_region):
                perks["mythical"] += 1
        return loot_found, perks, currencies

    def _scan_currency(self, frame, currency_cards):
        """OCR values only from cards whose Gold/Gem icons were actually recognized."""
        if os.name != "nt":
            return {}
        values = {"gold": None, "gems": 0}
        images, kinds = [], []
        for kind in ("gold", "gems"):
            card = currency_cards.get(kind)
            if card is None:
                continue
            x, y, w, h = card
            x1, x2 = x + round(w * 0.07), x + round(w * 0.93)
            y1, y2 = y + round(h * 0.67), y + round(h * 0.97)
            crop = frame[max(0, y1):min(frame.shape[0], y2),
                         max(0, x1):min(frame.shape[1], x2)]
            if crop.size == 0:
                continue
            images.append(cv2.resize(crop, None, fx=6, fy=6, interpolation=cv2.INTER_CUBIC))
            kinds.append(kind)
        if "gold" not in kinds:
            self._save_currency_ocr_debug(frame, images, "Gold reward card was not located")
            return values
        paths = []
        try:
            for image in images:
                ok, encoded = cv2.imencode(".png", image)
                if not ok:
                    continue
                with tempfile.NamedTemporaryFile(prefix="eclipse_currency_", suffix=".png",
                                                 delete=False) as image_file:
                    image_file.write(encoded.tobytes())
                    paths.append(image_file.name)
            script = os.path.join(RESOURCE_DIR, "ocr_windows.ps1")
            completed = subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy",
                 "Bypass", "-File", script, *paths],
                capture_output=True, text=True, timeout=12,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            if completed.returncode != 0:
                raise RuntimeError((completed.stderr or completed.stdout).strip() or
                                   f"PowerShell exited with code {completed.returncode}")
            rows = [line.partition(":")[2].strip()
                    for line in completed.stdout.splitlines()
                    if line.startswith("__ECLIPSE_OCR__:")]
            for kind, text in zip(kinds, rows):
                values[kind] = self._currency_integer(text)
            if values["gold"] is None or ("gems" in currency_cards and values["gems"] is None):
                self._save_currency_ocr_debug(frame, images,
                                              completed.stdout.strip() or "<empty OCR text>")
        except Exception as exc:
            self._save_currency_ocr_debug(frame, images,
                                          f"{type(exc).__name__}: {exc}")
        finally:
            for path in paths:
                try:
                    os.remove(path)
                except OSError:
                    pass
        return values

    @staticmethod
    def _currency_integer(text):
        digits = "".join(re.findall(r"\d", text or ""))
        if not digits or len(digits) > 12:
            return None
        try:
            return int(digits)
        except ValueError:
            return None

    def _save_currency_ocr_debug(self, frame, images, reason):
        if not self.currency_ocr_warned:
            self.currency_ocr_warned = True
            try:
                os.makedirs(DEBUG_DIR, exist_ok=True)
                cv2.imencode(".png", frame)[1].tofile(
                    os.path.join(DEBUG_DIR, "currency_ocr_result_screen.png"))
                for index, image in enumerate(images):
                    cv2.imencode(".png", image)[1].tofile(
                        os.path.join(DEBUG_DIR, f"currency_ocr_value_{index + 1}.png"))
                if images:
                    width = max(image.shape[1] for image in images)
                    rows = []
                    for image in images:
                        left = (width - image.shape[1]) // 2
                        rows.append(cv2.copyMakeBorder(
                            image, 0, 10, left, width - image.shape[1] - left,
                            cv2.BORDER_CONSTANT, value=(0, 0, 0)))
                    cv2.imencode(".png", cv2.vconcat(rows))[1].tofile(
                        os.path.join(DEBUG_DIR, "currency_ocr_input.png"))
            except Exception:
                pass
            self.log("Gold/Gems OCR issue: " + " ".join(str(reason).split()))
            self.log("Diagnostic images saved in the app's debug folder")

    def _queue_report_enrichment(self, result, seconds, frame):
        def process():
            try:
                anchor = self._result_anchor(frame)
                cards = self._find_reward_cards(frame, anchor)
                loot_found, perks, currency_cards = self._analyze_reward_cards(frame, cards)
                currency = self._scan_currency(frame, currency_cards)
                self._record_report_result(result, seconds, loot_found, frame, currency, perks)
                detected = [f"{LOOT_LABELS[k]} x{n}" for k, n in loot_found.items() if n]
                if detected:
                    self.log("Loot detected: " + ", ".join(detected))
                if currency.get("gold") is not None and currency.get("gems") is not None:
                    self.log(f"Reward OCR: Gold {currency['gold']:,}, Gems {currency['gems']:,}")
            except Exception as exc:
                self.log(f"Result report scan failed: {type(exc).__name__}: {exc}")
            finally:
                with self.report_jobs_lock:
                    self.report_jobs.discard(threading.current_thread())

        worker = threading.Thread(target=process, name="result-report-scan", daemon=True)
        with self.report_jobs_lock:
            self.report_jobs.add(worker)
        worker.start()

    def _wait_for_report_jobs(self, timeout):
        deadline = time.monotonic() + max(0.0, timeout)
        while time.monotonic() < deadline:
            with self.report_jobs_lock:
                pending = list(self.report_jobs)
            if not pending:
                return
            for worker in pending:
                worker.join(timeout=min(0.2, max(0.0, deadline - time.monotonic())))

    def _record_report_result(self, result, seconds, loot_found, frame, currency, perks):
        ok, png = (cv2.imencode(".png", frame) if frame is not None else (False, None))
        with self.report_lock:
            for bucket in (self.report_total, self.report_interval):
                bucket["missions"] += 1
                bucket[result] = bucket.get(result, 0) + 1
                bucket["mission_seconds"] += float(seconds)
                for kind, amount in loot_found.items():
                    bucket["loot"][kind] += int(amount)
                for kind in ("gold", "gems"):
                    value = currency.get(kind)
                    if value is not None:
                        bucket["currency"][kind] += int(value)
                        bucket["currency"][kind + "_readings"] += 1
                for rarity in bucket["perks"]:
                    bucket["perks"][rarity] += int(perks.get(rarity, 0))
            if ok:
                self.latest_completion_png = png.tobytes()
            self.last_result = result

    def _start_hourly_reporter(self):
        webhook = (self.s.get("discord_loot_webhook") or self.s.get("discord_webhook", "")).strip()
        if not self.s.get("hourly_report", True) or not webhook:
            return
        self.report_interval_started = time.monotonic()
        self.report_thread = threading.Thread(target=self._hourly_report_loop,
                                              name="hourly-webhook-report", daemon=True)
        self.report_thread.start()
        self.log("Hourly loot report enabled (first report in 60 minutes)")

    def _hourly_report_loop(self):
        next_report = time.monotonic() + HOURLY_REPORT_SECONDS
        while not self.hourly_report_stop.wait(max(0.0, next_report - time.monotonic())):
            self._wait_for_report_jobs(3.0)
            sent_at = time.monotonic()
            with self.report_lock:
                interval = json.loads(json.dumps(self.report_interval))
                totals = json.loads(json.dumps(self.report_total))
                png = self.latest_completion_png
                interval_started = self.report_interval_started or sent_at
                last_result = self.last_result
            if interval["missions"] == 0:
                next_report = sent_at + HOURLY_REPORT_SECONDS
                continue
            elapsed = max(0.0, sent_at - interval_started)
            runtime = max(0.0, sent_at - (self.runtime_started or sent_at))
            if self.send_hourly_report(interval, totals, runtime, elapsed, last_result, png):
                with self.report_lock:
                    for key in ("missions", "completed", "failed", "unknown", "timeouts"):
                        self.report_interval[key] -= interval[key]
                    self.report_interval["mission_seconds"] -= interval["mission_seconds"]
                    for kind in LOOT_TEMPLATE_FILES:
                        self.report_interval["loot"][kind] -= interval["loot"][kind]
                    for key in ("gold", "gems", "gold_readings", "gems_readings"):
                        self.report_interval["currency"][key] -= interval["currency"][key]
                    for rarity in self.report_interval["perks"]:
                        self.report_interval["perks"][rarity] -= interval["perks"][rarity]
                    self.report_interval_started = sent_at
            next_report = sent_at + HOURLY_REPORT_SECONDS

    @staticmethod
    def _format_duration(value):
        total = int(max(0, value))
        hours, rem = divmod(total, 3600)
        minutes, seconds = divmod(rem, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    @staticmethod
    def _loot_lines(counts, perks=None):
        rows = [f"{LOOT_LABELS[k]}: {counts.get(k, 0)}" for k in LOOT_TEMPLATE_FILES
                if counts.get(k, 0)]
        perks = perks or {"epic": 0, "legendary": 0, "mythical": 0}
        perks_line = (f"Perks — Epic {perks.get('epic', 0)}, "
                      f"Legendary {perks.get('legendary', 0)}, "
                      f"Mythical {perks.get('mythical', 0)}")
        if rows:
            rows.append(perks_line)
            return "\n".join(rows)
        return "No tracked drops detected\n" + perks_line

    def _queue_session_report(self):
        if self.runtime_started is None:
            return
        webhook = (self.s.get("discord_loot_webhook") or self.s.get("discord_webhook", "")).strip()
        if not webhook:
            return
        runtime = max(0.0, time.monotonic() - self.runtime_started)
        sender = threading.Thread(target=self._send_final_session_report, args=(runtime,),
                                  name="session-webhook-report", daemon=False)
        sender.start()
        self.log("Sending final macro session report to Discord")

    def _send_final_session_report(self, runtime):
        self._wait_for_report_jobs(15.0)
        with self.report_lock:
            totals = json.loads(json.dumps(self.report_total))
            png = self.latest_completion_png
            last_result = self.last_result
        self.send_hourly_report(totals, totals, runtime, runtime, last_result, png,
                                "Macro session report", "Session")

    @staticmethod
    def _currency_lines(bucket):
        currency = bucket["currency"]
        gold = (f"Gold: {currency['gold']:,} ({currency['gold_readings']} screens read)"
                if currency["gold_readings"] else "Gold: not read")
        gems = (f"Gems: {currency['gems']:,} ({currency['gems_readings']} screens read)"
                if currency["gems_readings"] else "Gems: not read")
        return gold + "\n" + gems

    def send_hourly_report(self, interval, totals, runtime_seconds, interval_seconds,
                           last_result, png, title="Hourly loot report", period_label="Last"):
        webhook = (self.s.get("discord_loot_webhook") or self.s.get("discord_webhook", "")).strip()
        if not webhook:
            return False
        hourly = interval["missions"] * 3600 / max(1.0, interval_seconds)
        content = (f"**Eclipse — {title}**\n"
                   f"{period_label} {self._format_duration(interval_seconds)}: {interval['missions']} missions "
                   f"(wins {interval['completed']}, fails {interval['failed']}, "
                   f"timeouts {interval['timeouts']})\n"
                   f"Since start: {totals['missions']} missions (wins {totals['completed']}, "
                   f"fails {totals['failed']}, timeouts {totals['timeouts']})\n"
                   f"Runtime: {self._format_duration(runtime_seconds)} | "
                   f"Missions/hour: {hourly:.1f}\n"
                   f"Loot this hour\n{self._loot_lines(interval['loot'], interval['perks'])}\n"
                   f"Loot since start\n{self._loot_lines(totals['loot'], totals['perks'])}\n"
                   f"Currencies this interval\n{self._currency_lines(interval)}\n"
                   f"Currencies since start\n{self._currency_lines(totals)}\n"
                   f"Latest result: {last_result or 'none'}")
        try:
            headers = {"User-Agent": "EclipseMacro/1.0"}
            if png:
                boundary = "----Eclipse" + uuid.uuid4().hex
                body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"payload_json\"\r\n"
                        "Content-Type: application/json\r\n\r\n" +
                        json.dumps({"content": content}) +
                        f"\r\n--{boundary}\r\nContent-Disposition: form-data; name=\"files[0]\"; filename=\"latest-mission-complete.png\"\r\n"
                        "Content-Type: image/png\r\n\r\n").encode("utf-8") + png + f"\r\n--{boundary}--\r\n".encode()
                headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"
            else:
                body = json.dumps({"content": content}).encode("utf-8")
                headers["Content-Type"] = "application/json"
            req = urllib.request.Request(webhook, data=body, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=15) as response:
                if response.status >= 300:
                    raise RuntimeError(f"HTTP {response.status}")
            self.log(f"Sent {title.lower()} to Discord")
            return True
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace").strip()
            self.log(f"Discord report returned HTTP {exc.code}" + (f": {detail}" if detail else ""))
        except Exception as exc:
            self.log(f"Discord report failed: {type(exc).__name__}: {exc}")
        return False

    def send_completion_screenshot(self, frame, stats, runtime_seconds):
        """Send the mission screenshot with cumulative run counts to the loot webhook."""
        try:
            ok, encoded = cv2.imencode(".png", frame)
            if not ok:
                raise RuntimeError("could not encode screenshot")
            boundary = "----Macro" + uuid.uuid4().hex
            png = encoded.tobytes()
            runtime = int(max(0, runtime_seconds))
            hours, remainder = divmod(runtime, 3600)
            minutes, seconds = divmod(remainder, 60)
            unknown = int(stats.get("unknown", 0))
            counts = (f"Missions Completed {stats['missions']} (wins {stats['completed']}, "
                      f"fails {stats['failed']}"
                      + (f", unknown {unknown}" if unknown else "") + ")")
            content = f"{counts}\nRuntime {hours:02d}:{minutes:02d}:{seconds:02d}"
            body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"payload_json\"\r\n"
                    "Content-Type: application/json\r\n\r\n"
                    + json.dumps({"content": content})
                    + f"\r\n--{boundary}\r\nContent-Disposition: form-data; name=\"files[0]\"; filename=\"mission-complete.png\"\r\n"
                    "Content-Type: image/png\r\n\r\n").encode("utf-8") + png + f"\r\n--{boundary}--\r\n".encode()
            webhook = (self.s.get("discord_loot_webhook") or self.s.get("discord_webhook", "")).strip()
            req = urllib.request.Request(webhook, data=body,
                                         headers={"Content-Type": f"multipart/form-data; boundary={boundary}",
                                                  "User-Agent": "ymir-macro/1.0"},
                                         method="POST")
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status >= 300:
                    raise RuntimeError(f"HTTP {response.status}")
            self.log("Sent mission-complete screenshot to Discord")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace").strip()
            if exc.code == 403:
                self.log("Discord webhook returned 403 Forbidden" + (f": {detail}" if detail else
                         ". Check that this is an active Discord webhook URL and is not blocked by network/server policy."))
            else:
                self.log(f"Discord webhook returned HTTP {exc.code}" + (f": {detail}" if detail else ""))
        except Exception as exc:
            self.log(f"Discord screenshot failed: {type(exc).__name__}: {exc}")

    def click_retry(self, info):
        if not info["retry"]:                             # only the banner was seen so far
            info = self.wait_for_retry()
            if not info:
                self.log("The Retry button never showed up")
                return
        self.set_status("Clicking retry")
        j = int(self.s["retry_jitter"])
        for _ in range(5):
            m, mon = info["retry"], info["mon"]
            self.io.click_abs(mon["left"] + m.x + random.randint(-j, j),
                              mon["top"] + m.y + random.randint(-j, j))
            self.sleep(1.2)
            frame, mon = self.vision.grab()
            info = self.detect_retry(frame, mon)
            if info is None:
                return
        self.log("Retry button still visible after 5 clicks")


