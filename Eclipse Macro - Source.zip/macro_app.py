"""
macro_app.py - the window. Run with:  python macro_app.py
All the real work happens in core.py.
"""
import ctypes
import json
import os
import queue
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import urllib.error
import urllib.request

import cv2
import numpy as np

import core

if sys.platform == "win32":                    # make screen coordinates match real pixels
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

THEMES = {
    "Midnight Teal": {"bg": "#0b1114", "card": "#121c23", "field": "#111b21", "surface": "#1b2931", "border": "#2a3b44", "accent": "#32d6a0", "text": "#e9f0f2", "muted": "#83929c", "button": "#263a44", "start": "#0c9c76"},
    "Black & Purple": {"bg": "#0c0912", "card": "#171222", "field": "#100d18", "surface": "#231a30", "border": "#3b2c4d", "accent": "#c09aff", "text": "#f0eaf7", "muted": "#a99bb9", "button": "#30233f", "start": "#7446a8"},
    "White & Black": {"bg": "#f0f1f3", "card": "#ffffff", "field": "#f8f9fa", "surface": "#e5e7ea", "border": "#c7cbd1", "accent": "#17191d", "text": "#17191d", "muted": "#626a73", "button": "#dfe2e6", "start": "#24272c"},
    "Midnight Blue": {"bg": "#08111d", "card": "#101d2d", "field": "#0c1725", "surface": "#182b42", "border": "#29415b", "accent": "#72b7ff", "text": "#e8f2fc", "muted": "#8ea5ba", "button": "#203650", "start": "#1767ad"},
}

def rounded_points(width, height, radius, steps=6):
    r = max(2, min(radius, width // 4, height // 4))
    pts = []
    for cx, cy, start in ((r, r, 180), (width-r, r, 270),
                          (width-r, height-r, 0), (r, height-r, 90)):
        for i in range(steps + 1):
            import math
            angle = math.radians(start + 90 * i / steps)
            pts.extend((cx + r * math.cos(angle), cy + r * math.sin(angle)))
    return pts

class RoundedButton(tk.Canvas):
    def __init__(self, master, text, command, fill, foreground, border, height=44, font_size=10):
        super().__init__(master, height=height, bg=master.winfo_toplevel().cget("bg"),
                         highlightthickness=0, bd=0, cursor="hand2")
        self._text, self._command = text, command
        self._fill, self._foreground, self._border = fill, foreground, border
        self._hover = fill
        self._hover_color = fill
        self._state = "normal"
        self._font_size = font_size
        self.bind("<Configure>", self._draw)
        self.bind("<Button-1>", self._invoke)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self._draw()

    def _draw(self, _event=None):
        self.delete("all")
        w, h = max(1, self.winfo_width()), max(1, self.winfo_height())
        fill = self._fill if self._state == "normal" else self._hover
        fg = self._foreground if self._state == "normal" else "#89929a"
        self.create_polygon(*rounded_points(w-1, h-1, 12), fill=fill, outline=self._border, width=1)
        self.create_text(w//2, h//2, text=self._text, fill=fg,
                         font=("Segoe UI", self._font_size, "bold"), justify="center")

    def _invoke(self, _event=None):
        if self._state == "normal" and self._command:
            self._command()

    def _on_enter(self, _event=None):
        self._hover = getattr(self, "_hover_color", self._fill)
        self._draw()

    def _on_leave(self, _event=None):
        self._hover = self._fill
        self._draw()

    def configure(self, cnf=None, **kw):
        if isinstance(cnf, dict):
            kw.update(cnf)
        changed = False
        if "text" in kw:
            self._text = kw.pop("text")
            changed = True
        if "state" in kw:
            self._state = kw.pop("state")
            changed = True
        result = super().configure(**kw)
        if changed:
            self._draw()
        return result

    config = configure

    def set_colors(self, fill, foreground, border, hover):
        self._fill, self._foreground, self._border, self._hover_color = fill, foreground, border, hover
        self._hover = fill
        self._draw()


class ModernScrollbar(tk.Canvas):
    """Slim draggable scroll track with a rounded slider thumb."""
    def __init__(self, master, command, width=14):
        bg = master.winfo_toplevel().cget("bg")
        super().__init__(master, width=width, bg=bg, bd=0, highlightthickness=0, cursor="hand2")
        self.command = command
        self.first, self.last = 0.0, 1.0
        self.track_color, self.thumb_color, self.active_color = "#1b2931", "#83929c", "#32d6a0"
        self.bg_color = bg
        self.hovered = False
        self.drag_offset = None
        self.thumb_top, self.thumb_height, self.track_top, self.track_height = 0, 0, 5, 0
        self.max_first = 0.0
        self.bind("<Configure>", self._draw)
        self.bind("<Button-1>", self._press)
        self.bind("<B1-Motion>", self._drag)
        self.bind("<ButtonRelease-1>", self._release)
        self.bind("<Enter>", self._enter)
        self.bind("<Leave>", self._leave)
        self._draw()

    def set(self, first, last):
        self.first, self.last = float(first), float(last)
        self._draw()

    def set_colors(self, bg, track, thumb, active):
        self.bg_color, self.track_color = bg, track
        self.thumb_color, self.active_color = thumb, active
        self.configure(bg=bg)
        self._draw()

    def _draw(self, _event=None):
        self.delete("all")
        w, h = max(8, self.winfo_width()), max(1, self.winfo_height())
        cx = w / 2
        self.track_top, self.track_height = 5, max(1, h - 10)
        self.create_line(cx, self.track_top, cx, h-5, fill=self.track_color,
                         width=4, capstyle="round")
        ratio = max(0.0, min(1.0, self.last - self.first))
        if ratio >= 0.995:
            self.thumb_height, self.thumb_top = self.track_height, self.track_top
            return
        self.thumb_height = min(self.track_height, max(26.0, self.track_height * ratio))
        max_top = self.track_top + self.track_height - self.thumb_height
        self.max_first = max(0.0, 1.0-ratio)
        scroll_fraction = (self.first / self.max_first) if self.max_first else 0.0
        self.thumb_top = self.track_top + max(0.0, min(1.0, scroll_fraction)) * (max_top-self.track_top)
        color = self.active_color if self.hovered or self.drag_offset is not None else self.thumb_color
        half = min(4, max(2, (w-4)//2))
        left, right = cx-half, cx+half
        top, bottom = self.thumb_top, self.thumb_top+self.thumb_height
        radius = min(half, self.thumb_height/2)
        points = []
        import math
        for xc, yc, start_angle in ((right-radius, top+radius, 270),
                                    (right-radius, bottom-radius, 0),
                                    (left+radius, bottom-radius, 90),
                                    (left+radius, top+radius, 180)):
            for i in range(7):
                angle = math.radians(start_angle + i*15)
                points.extend((xc+radius*math.cos(angle), yc+radius*math.sin(angle)))
        self.create_polygon(*points, fill=color, outline=color, width=1)

    def _move_to_y(self, y, offset=0):
        available = max(1.0, self.track_height-self.thumb_height)
        fraction = (y-offset-self.track_top) / available
        self.command("moveto", max(0.0, min(1.0, fraction)) * self.max_first)

    def _press(self, event):
        if self.last-self.first >= 0.995:
            return
        if self.thumb_top <= event.y <= self.thumb_top+self.thumb_height:
            self.drag_offset = event.y-self.thumb_top
        else:
            self.drag_offset = self.thumb_height/2
            self._move_to_y(event.y, self.drag_offset)
        self._draw()

    def _drag(self, event):
        if self.drag_offset is not None:
            self._move_to_y(event.y, self.drag_offset)

    def _release(self, _event=None):
        self.drag_offset = None
        self._draw()

    def _enter(self, _event=None):
        self.hovered = True
        self._draw()

    def _leave(self, _event=None):
        if self.drag_offset is None:
            self.hovered = False
            self._draw()


class RoundedEntry(tk.Frame):
    """Rounded border around a standard text entry, while keeping Tk text bindings."""
    def __init__(self, master, textvariable=None, show=None, width=22):
        bg = master.winfo_toplevel().cget("bg")
        super().__init__(master, bg=bg, bd=0, highlightthickness=0, height=36)
        self._bg, self._field, self._border, self._accent = bg, "#111b21", "#2a3b44", "#32d6a0"
        self._focused = False
        self.canvas = tk.Canvas(self, bg=bg, bd=0, highlightthickness=0)
        self.canvas.place(x=0, y=0, relwidth=1, relheight=1)
        self.entry = tk.Entry(self, textvariable=textvariable, show=show or "", width=width,
                              bg=self._field, fg="#e9f0f2", insertbackground="#e9f0f2",
                              selectbackground=self._accent, relief="flat", bd=0,
                              highlightthickness=0, font=("Segoe UI", 10))
        self.entry.pack(fill="both", expand=True, padx=11, pady=7)
        self.entry.bind("<FocusIn>", self._on_focus)
        self.entry.bind("<FocusOut>", self._on_blur)
        self.canvas.bind("<Configure>", self._draw)
        self._draw()

    def bind(self, sequence=None, func=None, add=None):
        return self.entry.bind(sequence, func, "+" if add is None else add)

    def _on_focus(self, _event=None):
        self._focused = True
        self._draw()

    def _on_blur(self, _event=None):
        self._focused = False
        self._draw()

    def _draw(self, _event=None):
        self.canvas.delete("all")
        w, h = max(1, self.winfo_width()), max(1, self.winfo_height())
        outline = self._accent if self._focused else self._border
        self.canvas.create_polygon(*rounded_points(w-1, h-1, 11),
                                   fill=self._field, outline=outline, width=1)

    def set_colors(self, bg, field, text, border, accent):
        self._bg, self._field, self._border, self._accent = bg, field, border, accent
        self.configure(bg=bg)
        self.canvas.configure(bg=bg)
        self.entry.configure(bg=field, fg=text, insertbackground=text, selectbackground=accent)
        self._draw()


class RoundedCombobox(tk.Frame):
    """Rounded frame around a themed readonly selector."""
    def __init__(self, master, textvariable, values, width=None):
        bg = master.winfo_toplevel().cget("bg")
        super().__init__(master, bg=bg, bd=0, highlightthickness=0, height=38)
        self._bg, self._field, self._border = bg, "#111b21", "#2a3b44"
        self.canvas = tk.Canvas(self, bg=bg, bd=0, highlightthickness=0)
        self.canvas.place(x=0, y=0, relwidth=1, relheight=1)
        self.combo = ttk.Combobox(self, textvariable=textvariable, values=values,
                                  state="readonly", width=width)
        self.combo.pack(fill="both", expand=True, padx=8, pady=5)
        self.canvas.bind("<Configure>", self._draw)
        self._draw()

    def bind(self, sequence=None, func=None, add=None):
        return self.combo.bind(sequence, func, add)

    def _draw(self, _event=None):
        self.canvas.delete("all")
        w, h = max(1, self.winfo_width()), max(1, self.winfo_height())
        self.canvas.create_polygon(*rounded_points(w-1, h-1, 11),
                                   fill=self._field, outline=self._border, width=1)

    def set_colors(self, bg, field, border):
        self._bg, self._field, self._border = bg, field, border
        self.configure(bg=bg)
        self.canvas.configure(bg=bg)
        self._draw()


class RoundedChoice(tk.Canvas):
    """Fully rounded, canvas-drawn selector with a native themed popup menu."""
    def __init__(self, master, textvariable, values, command=None, height=38):
        bg = master.winfo_toplevel().cget("bg")
        super().__init__(master, height=height, bg=bg, bd=0, highlightthickness=0, cursor="hand2")
        self.variable, self.values, self.command = textvariable, list(values), command
        self._bg, self._field, self._text = bg, "#111b21", "#e9f0f2"
        self._border, self._accent = "#2a3b44", "#32d6a0"
        self._hovered = False
        self.bind("<Configure>", self._draw)
        self.bind("<Button-1>", self._show_menu)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self._draw()

    def _draw(self, _event=None):
        self.delete("all")
        w, h = max(1, self.winfo_width()), max(1, self.winfo_height())
        self.create_polygon(*rounded_points(w-1, h-1, 12), fill=self._field,
                            outline=self._accent if self._hovered else self._border, width=1)
        self.create_text(13, h//2, text=self.variable.get(), fill=self._text,
                         font=("Segoe UI", 10), anchor="w")
        self.create_polygon(w-20, h//2-2, w-12, h//2-2, w-16, h//2+3,
                            fill=self._accent, outline=self._accent)

    def _on_enter(self, _event=None):
        self._hovered = True
        self._draw()

    def _on_leave(self, _event=None):
        self._hovered = False
        self._draw()

    def _show_menu(self, _event=None):
        menu = tk.Menu(self, tearoff=0, bg=self._field, fg=self._text,
                       activebackground=self._accent, activeforeground="#ffffff",
                       relief="flat", borderwidth=1, font=("Segoe UI", 10))
        self._menu = menu
        for item in self.values:
            menu.add_command(label=item, command=lambda value=item: self._choose(value))
        try:
            menu.tk_popup(self.winfo_rootx(), self.winfo_rooty() + self.winfo_height())
        finally:
            menu.grab_release()

    def _choose(self, value):
        self.variable.set(value)
        self._draw()
        if self.command:
            self.command()

    def set_colors(self, bg, field, text, border, accent):
        self._bg, self._field, self._text = bg, field, text
        self._border, self._accent = border, accent
        self.configure(bg=bg)
        self._draw()


class RoundedPanel(tk.Frame):
    """A lightly rounded card shell with a normal Tk content frame inside."""
    def __init__(self, master, title, padding=10, **kwargs):
        super().__init__(master, bd=0, highlightthickness=0, bg="#0b1114", **kwargs)
        self._title = title
        self._radius = 14
        self._outline = "#2a3b44"
        self._fill = "#0b1114"
        self.canvas = tk.Canvas(self, bd=0, highlightthickness=0)
        self.canvas.place(x=0, y=0, relwidth=1, relheight=1)
        self.title_label = ttk.Label(self, text=title, style="CardTitle.TLabel")
        self.title_label.grid(row=0, column=0, sticky="w", padx=padding+2, pady=(padding, 2))
        self.body = ttk.Frame(self, padding=padding)
        self.body.grid(row=1, column=0, sticky="nsew", padx=3, pady=(0, 3))
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        self.canvas.bind("<Configure>", self._draw)

    def _draw(self, _event=None):
        self.canvas.delete("all")
        w, h = max(1, self.winfo_width()), max(1, self.winfo_height())
        r = min(self._radius, w // 4, h // 4)
        self.canvas.create_polygon(*rounded_points(w-2, h-2, r),
                                   fill=self._fill, outline=self._outline, width=1)

    def set_colors(self, bg, fill, outline):
        self._fill, self._outline = fill, outline
        self.configure(bg=bg)
        self.canvas.configure(bg=bg)
        self._draw()



class App:
    def __init__(self, root):
        self.root = root
        root.title("Eclipse Macro")
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        size = f"{min(460, sw - 40)}x{min(760, sh - 80)}"
        pos = ""
        try:                                                        # reopen where it was last time
            x, y = core.load_settings().get("window_pos") or (None, None)
            if x is not None and root.winfo_vrootx() - 50 < x < root.winfo_vrootx() + root.winfo_vrootwidth() - 100 \
                    and root.winfo_vrooty() - 50 < y < root.winfo_vrooty() + root.winfo_vrootheight() - 100:
                pos = f"+{x}+{y}"
        except Exception:
            pass
        root.geometry(size + pos)
        root.minsize(300, 380)

        self.q = queue.Queue()
        self.settings = core.load_settings()
        self.discord_log_queue = queue.Queue()
        self.discord_log_stop = threading.Event()
        self.discord_log_thread = threading.Thread(target=self._discord_log_worker, daemon=True)
        self.discord_log_thread.start()
        self.stats = core.load_stats()
        self.runner = None
        self.recorder = None
        self.rec = None
        self.hotkeys_ok = False
        self.session_start = None
        self.countdown_window = None
        self.countdown_after_id = None
        self.start_pending = False
        self.runner_launch_time = None
        self._pump_error_logged = False
        self.rounded_buttons = []
        self.rounded_entries = []
        self.rounded_combos = []
        self.rounded_choices = []
        self.modern_scrollbars = []
        self.responsive_labels = []
        self._responsive_job = None
        self.active_tab = "Mission"

        core.prepare_user_files()
        # A saved recording path may come from another computer (or from the
        # build machine). Recover by filename when possible, then fall back to
        # the bundled Freedom Outskirts recording so the app never silently
        # opens with no recording selected after being moved or extracted.
        saved_recording = self.settings.get("recording") or ""
        if not os.path.isfile(saved_recording):
            candidates = []
            if saved_recording:
                candidates.append(os.path.basename(saved_recording))
            candidates.append("freedom_outskirts.json")
            recovered = next((os.path.join(core.RECORDING_DIR, name)
                              for name in dict.fromkeys(candidates)
                              if os.path.isfile(os.path.join(core.RECORDING_DIR, name))), "")
            if recovered != saved_recording:
                self.settings["recording"] = recovered
                core.save_settings(self.settings)
                self._recording_recovered_from = saved_recording
            else:
                self._recording_recovered_from = ""
        else:
            self._recording_recovered_from = ""

        self._build()
        try:
            self.logo_image = tk.PhotoImage(file=os.path.join(core.RESOURCE_DIR, "app-logo.png"))
            root.iconphoto(True, self.logo_image)
        except Exception:
            self.logo_image = None
        root.attributes("-topmost", bool(self.settings.get("always_on_top", False)))
        self._load_recording(self.settings["recording"], quiet=True)
        if self._recording_recovered_from and self.rec:
            self.log("The saved recording path was unavailable; recovered "
                     + os.path.basename(self.settings["recording"]) + " from this app folder.")
        self._register_hotkeys()
        self._show_stats(self.stats)
        self._refresh_templates()
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.bind("<Configure>", self._on_root_resize, add="+")
        root.after_idle(self._apply_responsive_widths)
        root.after(100, self._pump)

    # ------------------------------------------------------------------ UI
    # ------------------------------------------------------------------ UI
    def _set_theme_colors(self, name):
        self.theme_name = name if name in THEMES else "Midnight Teal"
        colors = THEMES[self.theme_name]
        for key, value in colors.items():
            setattr(self, key, value)
        self.button_hover = colors["button"]
        self.start_color = colors["start"]
        self.start_hover = colors["accent"]

    def _change_theme(self, *_):
        self._set_theme_colors(self.theme_var.get())
        style = ttk.Style()
        style.configure(".", background=self.bg, foreground=self.text)
        style.configure("TFrame", background=self.bg)
        style.configure("TLabel", background=self.bg, foreground=self.text)
        style.configure("CardTitle.TLabel", background=self.bg, foreground=self.accent,
                        font=("Segoe UI", 9, "bold"))
        style.configure("Brand.TLabel", background=self.bg, foreground=self.text,
                        font=("Segoe UI", 14, "bold"))
        style.configure("Accent.TLabel", background=self.bg, foreground=self.accent,
                        font=("Segoe UI", 14, "bold"))
        style.configure("Profile.TLabel", background=self.bg, foreground=self.text,
                        font=("Segoe UI", 16, "bold"))
        style.configure("Hint.TLabel", background=self.bg, foreground=self.muted)
        style.configure("Status.TLabel", background=self.bg, foreground=self.accent)
        style.configure("CardTitle.TLabel", background=self.bg, foreground=self.accent,
                        font=("Segoe UI", 9, "bold"))
        style.configure("Value.TLabel", background=self.card, foreground=self.text)
        style.configure("Metric.TLabel", background=self.card, foreground=self.muted)
        style.configure("TButton", background=self.surface, foreground=self.text, bordercolor=self.border, padding=(12, 8))
        style.map("TButton", background=[("active", self.button_hover), ("disabled", self.surface)])
        style.configure("TCheckbutton", background=self.bg, foreground=self.text)
        style.map("TCheckbutton", background=[("active", self.bg)])
        style.configure("Start.TButton", background=self.start_color, foreground="#ffffff",
                        font=("Segoe UI", 10, "bold"), padding=(5, 7))
        style.map("Start.TButton", background=[("active", self.start_hover)])
        style.configure("TEntry", fieldbackground=self.field, foreground=self.text,
                        insertcolor=self.text)
        style.configure("TCombobox", fieldbackground=self.field, background=self.surface,
                        foreground=self.text, arrowcolor=self.accent)
        style.map("TCombobox", fieldbackground=[("readonly", self.field)],
                  foreground=[("readonly", self.text)])
        style.configure("TNotebook", background=self.bg)
        style.configure("TNotebook.Tab", background=self.field, foreground=self.muted)
        style.map("TNotebook.Tab", background=[("selected", self.card)],
                  foreground=[("selected", self.accent)])
        self.root.configure(bg=self.bg)
        for combo in getattr(self, "rounded_combos", []):
            combo.set_colors(self.bg, self.field, self.border)
        for choice in getattr(self, "rounded_choices", []):
            choice.set_colors(self.bg, self.field, self.text, self.border, self.accent)
        for bar in getattr(self, "modern_scrollbars", []):
            bar.set_colors(self.bg, self.surface, self.muted, self.accent)
        for entry in getattr(self, "rounded_entries", []):
            entry.set_colors(self.bg, self.field, self.text, self.border, self.accent)
        for button in getattr(self, "rounded_buttons", []):
            if getattr(button, "_tab_name", None):
                selected = button._tab_name == self.active_tab
                fill = self.accent if selected else self.surface
                foreground = "#ffffff" if selected else self.text
                hover = self.accent if selected else self.button_hover
            else:
                primary = bool(getattr(button, "_is_primary", False))
                fill = self.start_color if primary else self.surface
                foreground = "#ffffff" if primary else self.text
                hover = self.start_hover if primary else self.button_hover
            button.set_colors(fill, foreground, self.border, hover)
        for card in getattr(self, "rounded_cards", []):
            card.set_colors(self.bg, self.card, self.border)
        def recolor(widget):
            if isinstance(widget, tk.Canvas):
                widget.configure(bg=self.bg)
            elif isinstance(widget, tk.Text):
                widget.configure(bg=self.field, fg=self.text,
                                 insertbackground=self.text, selectbackground=self.accent)
            elif isinstance(widget, tk.Frame):
                role = getattr(widget, "_theme_role", None)
                if role == "card":
                    widget.configure(bg=self.card, highlightbackground=self.border)
                elif isinstance(widget, RoundedPanel):
                    widget.configure(bg=self.bg)
            for child in widget.winfo_children():
                recolor(child)
        recolor(self.root)
        self.settings["theme"] = self.theme_name
        try:
            core.save_settings(self.settings)
        except OSError as exc:
            self.log(f"Could not save theme: {exc}")

    def _make_rounded_button(self, master, text, command, height=38, font_size=9, primary=False):
        fill = self.start_color if primary else self.surface
        foreground = "#ffffff" if primary else self.text
        button = RoundedButton(master, text, command, fill, foreground, self.border,
                               height=height, font_size=font_size)
        button._is_primary = primary
        button._tab_name = None
        button.set_colors(fill, foreground, self.border,
                          self.start_hover if primary else self.button_hover)
        self.rounded_buttons.append(button)
        return button

    def _make_rounded_entry(self, master, textvariable=None, show=None, width=22):
        entry = RoundedEntry(master, textvariable=textvariable, show=show, width=width)
        entry.set_colors(self.bg, self.field, self.text, self.border, self.accent)
        self.rounded_entries.append(entry)
        return entry

    def _make_rounded_combo(self, master, textvariable, values, width=None):
        combo = RoundedCombobox(master, textvariable=textvariable, values=values, width=width)
        combo.set_colors(self.bg, self.field, self.border)
        if not hasattr(self, "rounded_combos"):
            self.rounded_combos = []
        self.rounded_combos.append(combo)
        return combo

    def _make_rounded_choice(self, master, textvariable, values, command=None):
        choice = RoundedChoice(master, textvariable, values, command=command)
        choice.set_colors(self.bg, self.field, self.text, self.border, self.accent)
        self.rounded_choices.append(choice)
        return choice

    def _make_scrollbar(self, master, command):
        bar = ModernScrollbar(master, command)
        bar.set_colors(self.bg, self.surface, self.muted, self.accent)
        self.modern_scrollbars.append(bar)
        return bar

    def _register_responsive_label(self, label, horizontal_padding=28):
        self.responsive_labels.append((label, horizontal_padding))
        return label

    def _on_root_resize(self, event=None):
        if event is not None and event.widget is not self.root:
            return
        if self._responsive_job is not None:
            try:
                self.root.after_cancel(self._responsive_job)
            except tk.TclError:
                pass
        self._responsive_job = self.root.after_idle(self._apply_responsive_widths)

    def _apply_responsive_widths(self):
        self._responsive_job = None
        for label, padding in self.responsive_labels:
            try:
                available = max(140, label.master.winfo_width() - padding)
                label.configure(wraplength=available)
            except tk.TclError:
                continue

    def _update_template_hint(self):
        self.tpl_hint.configure(text=core.TEMPLATES[self.tpl_var.get()][1])

    def _select_tab(self, name):
        self.active_tab = name
        for tab_name, page in self.pages.items():
            if tab_name == name:
                page.grid()
                page.tkraise()
            else:
                page.grid_remove()
        for tab_name, button in self.tab_buttons.items():
            selected = tab_name == name
            button.set_colors(self.accent if selected else self.surface,
                              "#ffffff" if selected else self.text, self.border,
                              self.accent if selected else self.button_hover)

    def _build(self):
        style = ttk.Style()
        style.theme_use("clam")
        self._set_theme_colors(self.settings.get("theme", "Midnight Teal"))
        style.configure(".", background=self.bg, foreground=self.text, font=("Segoe UI", 10))
        style.configure("TFrame", background=self.bg)
        style.configure("TLabel", background=self.bg, foreground=self.text)
        style.configure("CardTitle.TLabel", background=self.bg, foreground=self.accent,
                        font=("Segoe UI", 9, "bold"))
        style.configure("Brand.TLabel", background=self.bg, foreground=self.text,
                        font=("Segoe UI", 14, "bold"))
        style.configure("Accent.TLabel", background=self.bg, foreground=self.accent,
                        font=("Segoe UI", 14, "bold"))
        style.configure("Profile.TLabel", background=self.bg, foreground=self.text,
                        font=("Segoe UI", 16, "bold"))
        style.configure("Hint.TLabel", background=self.bg, foreground=self.muted)
        style.configure("Status.TLabel", background=self.bg, foreground=self.accent,
                        font=("Segoe UI", 11, "bold"))
        style.configure("Value.TLabel", background=self.card, foreground=self.text,
                        font=("Segoe UI", 18, "bold"))
        style.configure("Metric.TLabel", background=self.card, foreground=self.muted,
                        font=("Segoe UI", 8, "bold"))
        style.configure("TLabelframe", background=self.bg, foreground=self.text,
                        bordercolor=self.border)
        style.configure("TLabelframe.Label", background=self.bg, foreground=self.accent,
                        font=("Segoe UI", 10, "bold"))
        style.configure("TButton", background=self.surface, foreground=self.text,
                        bordercolor=self.border, padding=(12, 8))
        style.map("TButton", background=[("active", self.button_hover), ("disabled", self.surface)])
        style.configure("Start.TButton", background=self.start_color, foreground="#ffffff",
                        font=("Segoe UI", 10, "bold"), padding=(5, 7))
        style.map("Start.TButton", background=[("active", self.start_hover)])
        style.configure("TCheckbutton", background=self.bg, foreground=self.text)
        style.map("TCheckbutton", background=[("active", self.bg)])
        style.configure("TEntry", fieldbackground=self.field, foreground=self.text,
                        insertcolor="#ffffff")
        style.configure("TCombobox", fieldbackground=self.field, background=self.surface,
                        foreground=self.text, arrowcolor=self.accent)
        style.map("TCombobox", fieldbackground=[("readonly", self.field)],
                  foreground=[("readonly", self.text)])
        style.configure("TNotebook", background=self.bg, borderwidth=0, tabmargins=(0, 0, 0, 0))
        style.configure("TNotebook.Tab", background=self.field, foreground=self.muted,
                        padding=(10, 7), font=("Segoe UI", 9, "bold"))
        style.map("TNotebook.Tab", background=[("selected", self.card)],
                  foreground=[("selected", self.accent)])

        self.root.configure(bg=self.bg)
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(2, weight=1)
        hk = self.settings["hotkeys"]

        header = ttk.Frame(self.root, padding=(12, 10, 12, 7))
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(1, weight=1)
        try:
            logo_path = os.path.join(getattr(sys, "_MEIPASS", os.path.dirname(__file__)), "app-logo.png")
            logo = tk.PhotoImage(file=logo_path)
            self.header_logo = logo.subsample(max(1, logo.width() // 42), max(1, logo.height() // 30))
            ttk.Label(header, image=self.header_logo).grid(row=0, column=0, rowspan=2,
                                                           sticky="w", padx=(0, 14))
        except Exception:
            self.header_logo = None
            ttk.Label(header, text="OM", foreground=self.accent,
                      font=("Segoe UI", 18, "bold")).grid(row=0, column=0, rowspan=2, padx=(0, 14))
        brand = ttk.Frame(header)
        brand.grid(row=0, column=1, sticky="w")
        ttk.Label(brand, text="ECLIPSE", style="Brand.TLabel").pack(side="left")
        ttk.Label(brand, text="  MACRO", style="Accent.TLabel").pack(side="left")
        ttk.Label(header, text="Mission automation  ·  Roblox",
                  style="Hint.TLabel").grid(row=1, column=1, sticky="w", pady=(1, 0))
        self.status_var = tk.StringVar(value="IDLE")
        self.status_label = ttk.Label(header, textvariable=self.status_var, style="Status.TLabel")
        self.status_label.grid(row=0, column=2, sticky="e", padx=(16, 0))
        self.rec_var = tk.StringVar(value="No recording loaded")
        self.rec_label = ttk.Label(header, textvariable=self.rec_var, style="Hint.TLabel",
                                   wraplength=380, justify="left")
        self.rec_label.grid(row=2, column=1, columnspan=2, sticky="w", pady=(5, 0))
        self._register_responsive_label(self.rec_label, 20)

        navigation = ttk.Frame(self.root, padding=(10, 2, 10, 6))
        navigation.grid(row=1, column=0, sticky="ew")
        for i in range(4):
            navigation.columnconfigure(i, weight=1, uniform="navigation")
        page_host = ttk.Frame(self.root)
        page_host.grid(row=2, column=0, sticky="nsew", padx=10, pady=(0, 6))
        page_host.columnconfigure(0, weight=1)
        page_host.rowconfigure(0, weight=1)
        dashboard = ttk.Frame(page_host)
        templates = ttk.Frame(page_host)
        settings_tab = ttk.Frame(page_host)
        credits = ttk.Frame(page_host)
        self.pages = {"Mission": dashboard, "Templates": templates,
                      "Settings": settings_tab, "Credits": credits}
        self.tab_buttons = {}
        for i, name in enumerate(self.pages):
            button = self._make_rounded_button(
                navigation, name.upper(), lambda tab=name: self._select_tab(tab), height=36, font_size=9)
            button._tab_name = name
            self.tab_buttons[name] = button
            button.grid(row=0, column=i, sticky="ew", padx=3)
        for page in self.pages.values():
            page.grid(row=0, column=0, sticky="nsew")
            page.grid_remove()

        # Mission-first dashboard. Its canvas scrolls vertically while the action bar stays fixed.
        dashboard.columnconfigure(0, weight=1)
        dashboard.rowconfigure(0, weight=1)
        dash_canvas = tk.Canvas(dashboard, bg=self.bg, highlightthickness=0)
        dash_scrollbar = self._make_scrollbar(dashboard, dash_canvas.yview)
        dash_canvas.configure(yscrollcommand=dash_scrollbar.set)
        dash_canvas.grid(row=0, column=0, sticky="nsew")
        dash_scrollbar.grid(row=0, column=1, sticky="ns")
        dash_content = ttk.Frame(dash_canvas, padding=10)
        dash_window = dash_canvas.create_window((0, 0), window=dash_content, anchor="nw")
        dash_content.columnconfigure(0, weight=1)
        dash_content.bind("<Configure>", lambda _e: dash_canvas.configure(
            scrollregion=dash_canvas.bbox("all")))
        dash_canvas.bind("<Configure>", lambda e: dash_canvas.itemconfigure(
            dash_window, width=e.width))
        dash_canvas.bind("<Enter>", lambda _e: self.root.bind_all(
            "<MouseWheel>", lambda e: dash_canvas.yview_scroll(-int(e.delta / 120), "units")))
        dash_canvas.bind("<Leave>", lambda _e: self.root.unbind_all("<MouseWheel>"))

        profile_card = RoundedPanel(dash_content, "CURRENT PROFILE", padding=9)
        profile_card.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        profile = profile_card.body
        self.profile_var = tk.StringVar(value="Freedom Outskirts")
        ttk.Label(profile, textvariable=self.profile_var, style="Profile.TLabel").pack(anchor="w")
        self.profile_detail_var = tk.StringVar(value="Load a recording to begin")
        self.profile_detail_label = ttk.Label(profile, textvariable=self.profile_detail_var,
                                              style="Hint.TLabel", wraplength=380, justify="left")
        self.profile_detail_label.pack(anchor="w", pady=(4, 10))
        self._register_responsive_label(self.profile_detail_label, 24)
        self.profile_start_button = self._make_rounded_button(
            profile, f"START MACRO    {hk['start'].upper()}", self.cmd_start,
            height=48, font_size=11, primary=True)
        self.profile_start_button.pack(fill="x")

        stats_card = RoundedPanel(dash_content, "SESSION SUMMARY", padding=6)
        stats_card.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        stats = stats_card.body
        self.stat_vars = {}
        for i, (name, caption) in enumerate((("Completed", "COMPLETED"),
                                             ("Failed", "FAILED"),
                                             ("Session", "RUN TIME"))):
            value = tk.StringVar(value="0" if name != "Session" else "00:00")
            self.stat_vars[name] = value
            tile = tk.Frame(stats, bg=self.card, padx=9, pady=8,
                            highlightthickness=1, highlightbackground=self.border)
            tile._theme_role = "card"
            tile.grid(row=0, column=i, sticky="ew", padx=3, pady=3)
            ttk.Label(tile, text=caption, style="Metric.TLabel").pack(anchor="w")
            ttk.Label(tile, textvariable=value, style="Value.TLabel").pack(anchor="w", pady=(4, 0))
            stats.columnconfigure(i, weight=1, uniform="summary")

        activity_card = RoundedPanel(dash_content, "LATEST ACTIVITY", padding=6)
        activity_card.grid(row=2, column=0, sticky="ew", pady=(0, 10))
        activity = activity_card.body
        activity.columnconfigure(0, weight=1)
        self.log_box = tk.Text(activity, height=9, state="disabled", wrap="word",
                               font=("Consolas", 9), bg=self.field, fg=self.text,
                               insertbackground="#ffffff", selectbackground="#176d5a",
                               relief="flat", padx=8, pady=8)
        log_scrollbar = self._make_scrollbar(activity, self.log_box.yview)
        self.log_box.configure(yscrollcommand=log_scrollbar.set)
        self.log_box.grid(row=0, column=0, sticky="nsew")
        log_scrollbar.grid(row=0, column=1, sticky="ns")

        quick = ttk.Frame(dash_content)
        quick.grid(row=3, column=0, sticky="ew")
        quick.columnconfigure(0, weight=1, uniform="quick-action")
        quick.columnconfigure(1, weight=1, uniform="quick-action")
        self._make_rounded_button(quick, "LOAD RECORDING", self.load_dialog).grid(
            row=0, column=0, sticky="ew", padx=(0, 4))
        self._make_rounded_button(quick, "RESET STATS", self.reset_stats).grid(
            row=0, column=1, sticky="ew", padx=(4, 0))

        # Template tools are also scrollable for short or narrow windows.
        templates.columnconfigure(0, weight=1)
        templates.rowconfigure(0, weight=1)
        tpl_canvas = tk.Canvas(templates, bg=self.bg, highlightthickness=0)
        tpl_scrollbar = self._make_scrollbar(templates, tpl_canvas.yview)
        tpl_canvas.configure(yscrollcommand=tpl_scrollbar.set)
        tpl_canvas.grid(row=0, column=0, sticky="nsew")
        tpl_scrollbar.grid(row=0, column=1, sticky="ns")
        tpl_content = ttk.Frame(tpl_canvas, padding=10)
        tpl_window = tpl_canvas.create_window((0, 0), window=tpl_content, anchor="nw")
        tpl_content.columnconfigure(0, weight=1)
        tpl_content.bind("<Configure>", lambda _e: tpl_canvas.configure(
            scrollregion=tpl_canvas.bbox("all")))
        tpl_canvas.bind("<Configure>", lambda e: tpl_canvas.itemconfigure(
            tpl_window, width=e.width))
        tpl_canvas.bind("<Enter>", lambda _e: self.root.bind_all(
            "<MouseWheel>", lambda e: tpl_canvas.yview_scroll(-int(e.delta / 120), "units")))
        tpl_canvas.bind("<Leave>", lambda _e: self.root.unbind_all("<MouseWheel>"))
        template_shell = RoundedPanel(tpl_content, "SCREEN MATCHING", padding=9)
        template_shell.grid(row=0, column=0, sticky="ew")
        template_card = template_shell.body
        self.tpl_var = tk.StringVar(value="retry")
        self.tpl_combo = self._make_rounded_choice(
            template_card, self.tpl_var, list(core.TEMPLATES), command=self._update_template_hint)
        self.tpl_combo.pack(fill="x", pady=(0, 8))
        self._make_rounded_button(template_card, "CAPTURE REGION",
                                  self.capture_template).pack(fill="x")
        self._make_rounded_button(template_card, "TEST DETECTION  ·  3 SEC",
                                  self.test_detection).pack(fill="x", pady=(8, 0))
        self.tpl_hint = ttk.Label(template_card, text=core.TEMPLATES["retry"][1],
                                  style="Hint.TLabel", wraplength=360, justify="left")
        self.tpl_hint.pack(anchor="w", pady=(12, 0))
        self._register_responsive_label(self.tpl_hint, 32)
        self.tpl_status = ttk.Label(template_card, text="", justify="left", wraplength=360)
        self.tpl_status.pack(anchor="w", pady=(12, 0))
        self._register_responsive_label(self.tpl_status, 32)
        self.template_folder_hint = ttk.Label(
            tpl_content, text="Templates are saved beside the executable in the templates folder.",
            style="Hint.TLabel", wraplength=360, justify="left")
        self.template_folder_hint.grid(row=1, column=0, sticky="w", pady=(10, 0))
        self._register_responsive_label(self.template_folder_hint, 30)

        # Settings tab: narrow single-column layout inside a scrollable view.
        settings_tab.columnconfigure(0, weight=1)
        settings_tab.rowconfigure(0, weight=1)
        settings_canvas = tk.Canvas(settings_tab, bg=self.bg, highlightthickness=0)
        settings_scrollbar = self._make_scrollbar(settings_tab, settings_canvas.yview)
        settings_canvas.configure(yscrollcommand=settings_scrollbar.set)
        settings_canvas.grid(row=0, column=0, sticky="nsew")
        settings_scrollbar.grid(row=0, column=1, sticky="ns")
        settings_content = ttk.Frame(settings_canvas, padding=9)
        settings_content.columnconfigure(0, weight=1)
        settings_window = settings_canvas.create_window((0, 0), window=settings_content, anchor="nw")
        settings_content.bind("<Configure>", lambda _e: settings_canvas.configure(
            scrollregion=settings_canvas.bbox("all")))
        settings_canvas.bind("<Configure>", lambda e: settings_canvas.itemconfigure(
            settings_window, width=e.width))
        settings_canvas.bind("<Enter>", lambda _e: self.root.bind_all(
            "<MouseWheel>", lambda e: settings_canvas.yview_scroll(-int(e.delta / 120), "units")))
        settings_canvas.bind("<Leave>", lambda _e: self.root.unbind_all("<MouseWheel>"))
        playback_shell = RoundedPanel(settings_content, "PLAYBACK", padding=8)
        playback_shell.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        playback = playback_shell.body
        playback.columnconfigure(0, weight=1)
        self.setting_vars = {}
        fields = [("failsafe_after", "Failsafe after (s)"),
                  ("mission_timeout", "Mission timeout (s)"),
                  ("threshold", "Match threshold"), ("load_timeout", "Load timeout (s)"),
                  ("speed", "Playback speed"), ("start_delay", "Start delay (s)*"),
                  ("failsafe_start", "Failsafe starts at (s)**"),
                  ("start_at", "Mission starts at (s)***")]
        for i, (key, label) in enumerate(fields):
            label_row, entry_row = i * 2, i * 2 + 1
            ttk.Label(playback, text=label).grid(row=label_row, column=0, sticky="w", padx=2, pady=(6, 1))
            value = tk.StringVar(value=str(self.settings[key]))
            self.setting_vars[key] = value
            entry = self._make_rounded_entry(playback, textvariable=value, width=12)
            entry.grid(row=entry_row, column=0, sticky="ew", pady=(0, 3))
            entry.bind("<FocusOut>", self._apply_settings)
            entry.bind("<Return>", self._apply_settings)
        self.windowed_var = tk.BooleanVar(value=bool(self.settings["windowed"]))
        ttk.Checkbutton(playback, text="Windowed game mode", variable=self.windowed_var,
                        command=self._apply_settings).grid(row=16, column=0, sticky="w",
                                                           padx=2, pady=(9, 3))
        ttk.Label(playback, text="Window title").grid(row=17, column=0, sticky="w", padx=2, pady=(6, 1))
        self.title_var = tk.StringVar(value=str(self.settings["window_title"]))
        title_entry = self._make_rounded_entry(playback, textvariable=self.title_var, width=20)
        title_entry.grid(row=18, column=0, sticky="ew", pady=(0, 3))
        title_entry.bind("<FocusOut>", self._apply_settings)
        title_entry.bind("<Return>", self._apply_settings)
        self._make_rounded_button(playback, "CHECK WINDOW", self.check_window).grid(
            row=19, column=0, sticky="ew", pady=(4, 2))
        self.skip_var = tk.BooleanVar(value=bool(self.settings["skip_lead_in"]))
        ttk.Checkbutton(playback, text="Skip recording lead-in (advanced)",
                        variable=self.skip_var, command=self._apply_settings).grid(
            row=20, column=0, sticky="w", padx=2, pady=(7, 2))
        self.topmost_var = tk.BooleanVar(value=bool(self.settings.get("always_on_top", False)))
        ttk.Checkbutton(playback, text="Keep app window always on top",
                        variable=self.topmost_var, command=self._apply_settings).grid(
            row=21, column=0, sticky="w", padx=2, pady=2)
        self.playback_hint = ttk.Label(playback, style="Hint.TLabel", wraplength=300, justify="left", text=(
            "* Used if the game start template is not set.\n"
            "** Recording time where failsafe actions begin.\n"
            "*** Recording time where the mission starts."))
        self.playback_hint.grid(row=22, column=0, sticky="w", padx=2, pady=(8, 0))
        self._register_responsive_label(self.playback_hint, 28)

        notifications_shell = RoundedPanel(settings_content, "DISCORD NOTIFICATIONS", padding=8)
        notifications_shell.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        notifications = notifications_shell.body
        notifications.columnconfigure(0, weight=1)
        ttk.Label(notifications, text="Loot screenshot channel").grid(row=0, column=0, sticky="w", pady=4)
        self.loot_webhook_var = tk.StringVar(value=str(
            self.settings.get("discord_loot_webhook") or self.settings.get("discord_webhook", "")))
        loot_entry = self._make_rounded_entry(notifications, textvariable=self.loot_webhook_var, show="*", width=32)
        loot_entry.grid(row=1, column=0, sticky="ew", pady=(0, 6))
        loot_entry.bind("<FocusOut>", self._apply_settings)
        loot_entry.bind("<Return>", self._apply_settings)
        ttk.Label(notifications, text="Log channel").grid(row=2, column=0, sticky="w", pady=4)
        self.log_webhook_var = tk.StringVar(value=str(self.settings.get("discord_log_webhook", "")))
        log_entry = self._make_rounded_entry(notifications, textvariable=self.log_webhook_var, show="*", width=32)
        log_entry.grid(row=3, column=0, sticky="ew", pady=(0, 6))
        log_entry.bind("<FocusOut>", self._apply_settings)
        log_entry.bind("<Return>", self._apply_settings)
        self.hourly_report_var = tk.BooleanVar(value=bool(self.settings.get("hourly_report", True)))
        ttk.Checkbutton(notifications, text="Send hourly loot report",
                        variable=self.hourly_report_var, command=self._apply_settings).grid(
            row=4, column=0, sticky="w", pady=(4, 0))
        self.discord_hint = ttk.Label(
            notifications, text="Use one webhook per Discord channel. Logs are sent in batches. "
                               "Hourly reports count detected loot icons and attach the latest result screenshot.",
            style="Hint.TLabel", wraplength=300, justify="left")
        self.discord_hint.grid(row=5, column=0, sticky="w", pady=(4, 0))
        self._register_responsive_label(self.discord_hint, 28)

        theme_shell = RoundedPanel(settings_content, "APPEARANCE", padding=8)
        theme_shell.grid(row=2, column=0, sticky="ew", pady=(0, 10))
        theme_box = theme_shell.body
        theme_box.columnconfigure(0, weight=1)
        ttk.Label(theme_box, text="Theme colors", style="Hint.TLabel").grid(
            row=0, column=0, sticky="w", pady=(0, 5))
        self.theme_var = tk.StringVar(value=self.settings.get("theme", "Midnight Teal"))
        self.theme_combo = self._make_rounded_choice(
            theme_box, self.theme_var, list(THEMES), command=self._change_theme)
        self.theme_combo.grid(row=1, column=0, sticky="ew")

        credits.columnconfigure(0, weight=1)
        credits.rowconfigure(0, weight=1)
        credits_canvas = tk.Canvas(credits, bg=self.bg, highlightthickness=0)
        credits_scrollbar = self._make_scrollbar(credits, credits_canvas.yview)
        credits_canvas.configure(yscrollcommand=credits_scrollbar.set)
        credits_canvas.grid(row=0, column=0, sticky="nsew")
        credits_scrollbar.grid(row=0, column=1, sticky="ns")
        credits_content = ttk.Frame(credits, padding=10)
        credits_window = credits_canvas.create_window((0, 0), window=credits_content, anchor="nw")
        credits_content.columnconfigure(0, weight=1)
        credits_content.bind("<Configure>", lambda _e: credits_canvas.configure(
            scrollregion=credits_canvas.bbox("all")))
        credits_canvas.bind("<Configure>", lambda e: credits_canvas.itemconfigure(
            credits_window, width=e.width))
        credits_canvas.bind("<Enter>", lambda _e: self.root.bind_all(
            "<MouseWheel>", lambda e: credits_canvas.yview_scroll(-int(e.delta / 120), "units")))
        credits_canvas.bind("<Leave>", lambda _e: self.root.unbind_all("<MouseWheel>"))
        credits_shell = RoundedPanel(credits_content, "CREDITS", padding=16)
        credits_shell.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        credits_body = credits_shell.body
        discord_mark = tk.Canvas(credits_body, width=76, height=60, bg=self.bg,
                                 highlightthickness=0)
        discord_mark.pack(pady=(8, 12))
        discord_mark.create_polygon(14, 15, 24, 9, 31, 11, 45, 11, 53, 9, 63, 15,
                                    68, 39, 60, 48, 51, 43, 47, 39, 30, 39, 25, 44,
                                    16, 48, 8, 39, fill=self.accent, outline=self.accent,
                                    smooth=True, splinesteps=20)
        discord_mark.create_oval(25, 26, 31, 32, fill=self.bg, outline=self.bg)
        discord_mark.create_oval(45, 26, 51, 32, fill=self.bg, outline=self.bg)
        ttk.Label(credits_body, text="DISCORD", style="Metric.TLabel").pack(pady=(0, 4))
        ttk.Label(credits_body, text="novaa", style="Profile.TLabel").pack(pady=(0, 8))
        self.credits_hint = ttk.Label(credits_body, text="Thank you for using Eclipse.",
                                      style="Hint.TLabel", justify="center", wraplength=320)
        self.credits_hint.pack()
        self._register_responsive_label(self.credits_hint, 30)

        self.rounded_cards = [profile_card, stats_card, activity_card, template_shell,
                              playback_shell, notifications_shell, theme_shell, credits_shell]
        for card in self.rounded_cards:
            card.set_colors(self.bg, self.card, self.border)
        self._select_tab("Mission")
        # Always-visible playback controls
        controls = ttk.Frame(self.root, padding=(8, 0, 8, 9))
        controls.grid(row=3, column=0, sticky="ew")
        for col in range(3):
            controls.columnconfigure(col, weight=1, uniform="control")
        self.btn_start = self._make_rounded_button(controls, f"START  {hk['start'].upper()}",
                                                  self.cmd_start, height=44, primary=True)
        self.btn_pause = self._make_rounded_button(controls, f"PAUSE  {hk['pause'].upper()}",
                                                  self.cmd_pause, height=44)
        self.btn_stop = self._make_rounded_button(controls, f"STOP  {hk['stop'].upper()}",
                                                 self.cmd_stop, height=44)
        for col, button in enumerate((self.btn_start, self.btn_pause, self.btn_stop)):
            button.grid(row=0, column=col, sticky="ew", padx=4)


    STATUS_COLORS = (("RECORDING", "#c62828"), ("Paused", "#ef6c00"), ("Stopping", "#ef6c00"),
                     ("Running", "#2e7d32"), ("Waiting", "#1565c0"), ("Clicking", "#1565c0"))

    def _set_status(self, text):
        self.status_var.set(text)
        color = self.accent if text != "IDLE" else self.muted
        for prefix, c in self.STATUS_COLORS:
            if text.startswith(prefix):
                color = self.accent if prefix in ("Running", "Waiting", "Clicking") else c
                break
        self.status_label.configure(foreground=color)

    # ------------------------------------------------------------------ helpers
    def log(self, msg, remote=True):
        stamp = time.strftime("%H:%M:%S  ") + msg
        self.log_box.configure(state="normal")
        self.log_box.insert("end", stamp + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")
        if remote and self.settings.get("discord_log_webhook", "").strip():
            self.discord_log_queue.put(stamp)

    def _discord_log_worker(self):
        """Batch log lines so Discord receives readable, rate-limited updates."""
        pending = []
        last_flush = time.monotonic()
        while not self.discord_log_stop.is_set() or not self.discord_log_queue.empty():
            try:
                pending.append(self.discord_log_queue.get(timeout=0.5))
            except queue.Empty:
                pass
            ready = (pending and (time.monotonic() - last_flush >= 5.0
                                  or sum(len(line) + 1 for line in pending) >= 1700
                                  or self.discord_log_stop.is_set()))
            if not ready:
                continue
            webhook = self.settings.get("discord_log_webhook", "").strip()
            batch, pending = pending, []
            last_flush = time.monotonic()
            if not webhook:
                continue
            text = "\n".join(batch)
            while text:
                chunk, text = text[:1850], text[1850:]
                payload = json.dumps({"content": "```text\n" + chunk.replace("```", "'''") + "\n```"}).encode("utf-8")
                try:
                    req = urllib.request.Request(webhook, data=payload,
                                                 headers={"Content-Type": "application/json",
                                                          "User-Agent": "ymir-macro/1.0"}, method="POST")
                    with urllib.request.urlopen(req, timeout=8):
                        pass
                except urllib.error.HTTPError as exc:
                    detail = exc.read().decode("utf-8", errors="replace").strip()
                    self.q.put(("discord_error", f"Discord log webhook returned HTTP {exc.code}"
                                + (f": {detail}" if detail else "")))
                    break
                except Exception as exc:
                    self.q.put(("discord_error", f"Discord log webhook failed: {type(exc).__name__}: {exc}"))
                    break

    def _show_stats(self, st):
        self.stat_vars["Completed"].set(st["completed"])
        self.stat_vars["Failed"].set(st["failed"] + st["unknown"])

    def _refresh_templates(self):
        lines = []
        for name, (required, desc) in core.TEMPLATES.items():
            have = os.path.exists(os.path.join(core.TEMPLATE_DIR, name + ".png"))
            mark = "OK " if have else ("MISSING (required)" if required else "not set (optional)")
            lines.append(f"{name}: {mark}")
        self.tpl_status.configure(text="   |   ".join(lines[:2]) + "\n" + "   |   ".join(lines[2:]))

    def _apply_settings(self, *_):
        """Read the fields into the settings and save them. Called when you leave a field, press
        Enter, tick the checkbox, press Start and when the app closes."""
        for key, var in self.setting_vars.items():
            try:
                self.settings[key] = float(var.get())
            except ValueError:
                var.set(str(self.settings[key]))
        self.settings["threshold"] = min(0.99, max(0.3, self.settings["threshold"]))
        self.settings["skip_lead_in"] = bool(self.skip_var.get())
        self.settings["windowed"] = bool(self.windowed_var.get())
        self.settings["window_title"] = (self.title_var.get() or "Roblox").strip()
        self.settings["always_on_top"] = bool(self.topmost_var.get())
        loot_hook = self.loot_webhook_var.get().strip()
        self.settings["discord_loot_webhook"] = loot_hook
        self.settings["discord_webhook"] = loot_hook  # legacy alias for existing settings
        self.settings["discord_log_webhook"] = self.log_webhook_var.get().strip()
        self.settings["hourly_report"] = bool(self.hourly_report_var.get())
        self.root.attributes("-topmost", self.settings["always_on_top"])
        try:
            core.save_settings(self.settings)
        except OSError as exc:
            self.log(f"Could not save settings to {core.SETTINGS_PATH}: {exc} "
                     "(is the app running from inside the zip? Extract it first.)")

    def _set_running_ui(self, running):
        self.btn_start.configure(state="disabled" if running else "normal")
        self.profile_start_button.configure(state="disabled" if running else "normal")
        self.btn_pause.configure(state="normal" if running else "disabled")
        self.btn_stop.configure(state="normal" if running else "disabled")

    # ------------------------------------------------------------------ hotkeys
    def _register_hotkeys(self):
        try:
            import keyboard
            for name, key in self.settings["hotkeys"].items():
                keyboard.add_hotkey(key, lambda n=name: self.q.put(("cmd", n)))
            self.hotkeys_ok = True
        except Exception as exc:
            self.log(f"Hotkeys unavailable ({exc}). Use the buttons instead.")

    # ------------------------------------------------------------------ commands
    def cmd_start(self):
        if self.runner and self.runner.alive:
            return
        if self.start_pending:
            return
        if self.recorder and self.recorder.active:
            return self.log("Stop recording first")
        if not self.rec:
            return messagebox.showinfo("No recording", "Record or load a recording first.")
        if not os.path.exists(os.path.join(core.TEMPLATE_DIR, "retry.png")):
            return messagebox.showinfo(
                "Missing template",
                "Capture the 'retry' template first - the macro clicks it after every mission.")
        self._apply_settings()
        files = [f for f in os.listdir(core.TEMPLATE_DIR) if f.lower().endswith((".png", ".jpg", ".jpeg"))]
        known = [n for n in core.TEMPLATES if n + ".png" in files]
        self.log("Templates in use: " + (", ".join(known) or "none"))
        allowed = (set(core.TEMPLATES) | set(core.LOOT_TEMPLATE_FILES.values()) |
                   {core.CURRENCY_GEM_ICON})
        unknown = [f for f in files if os.path.splitext(f)[0] not in allowed or
                   not f.lower().endswith(".png")]
        if unknown:
            self.log("WARNING: these files are NOT used (wrong name, must be exactly "
                     + ", ".join(n + ".png" for n in core.TEMPLATES) + "): " + ", ".join(unknown))
        if "result_completed" not in known:
            self.log("Tip: without result_completed.png the mission only ends when the Retry button "
                     "shows, so the failsafe can fire while the 'Mission Completed' screen is up.")
        if not os.path.exists(os.path.join(core.TEMPLATE_DIR, "start.png")):
            self.log("Tip: capture a 'start' template (something only visible in the mission, like the "
                     "skill bar) so the macro waits for the game to load.")
        self.log("Using recording file: " + str(self.settings.get("recording", "")))
        self._start_countdown(3)

    def _start_countdown(self, remaining):
        if self.countdown_window is None:
            self.start_pending = True
            self._set_status("Starting...")
            self.btn_stop.configure(state="normal")
            self.countdown_window = tk.Toplevel(self.root)
            self.countdown_window.title("Starting macro")
            self.countdown_window.attributes("-topmost", True)
            self.countdown_window.configure(bg="#111827")
            self.countdown_window.resizable(False, False)
            self.countdown_label = tk.Label(self.countdown_window, text="", bg="#111827", fg="#f9fafb",
                                            font=("Segoe UI", 34, "bold"), padx=28, pady=18)
            self.countdown_label.pack()
            self.countdown_window.update_idletasks()
            x = (self.root.winfo_screenwidth() - self.countdown_window.winfo_width()) // 2
            self.countdown_window.geometry(f"+{max(0, x)}+18")
        if remaining > 0:
            self.countdown_label.configure(text=f"Starting in\n{remaining}...")
            self.countdown_after_id = self.root.after(
                1000, lambda: self._start_countdown(remaining - 1))
            return
        self.countdown_label.configure(text="GO!")
        self.countdown_after_id = self.root.after(450, self._launch_runner)

    def _launch_runner(self):
        if self.countdown_window is not None:
            self.countdown_window.destroy()
            self.countdown_window = None
        self.start_pending = False
        self.countdown_after_id = None
        self.runner = core.Runner(self.settings, self.rec, self.stats,
                                  lambda kind, payload: self.q.put((kind, payload)))
        self.session_start = time.time()
        self.runner_launch_time = time.monotonic()
        self._set_running_ui(True)
        self._set_status("Starting...")
        self.log("Starting playback worker")
        try:
            self.runner.start()
        except Exception as exc:
            self.session_start = None
            self.runner_launch_time = None
            self._set_running_ui(False)
            self._set_status("IDLE")
            self.log(f"Could not start playback worker: {type(exc).__name__}: {exc}")
            messagebox.showerror("Could not start macro", f"{type(exc).__name__}: {exc}")

    def cmd_pause(self):
        if self.runner and self.runner.alive:
            paused = self.runner.toggle_pause()
            self.btn_pause.configure(text="Resume" if paused else
                                     f"Pause ({self.settings['hotkeys']['pause'].upper()})")
        elif self.start_pending:
            self.log("Pause is available after startup; press Stop to cancel the countdown.")
        else:
            self.log("The macro is not running; there is nothing to pause.")

    def cmd_stop(self):
        if self.start_pending:
            if self.countdown_after_id is not None:
                try:
                    self.root.after_cancel(self.countdown_after_id)
                except tk.TclError:
                    pass
                self.countdown_after_id = None
            if self.countdown_window is not None:
                try:
                    self.countdown_window.destroy()
                except tk.TclError:
                    pass
                self.countdown_window = None
            self.start_pending = False
            self._set_running_ui(False)
            self._set_status("IDLE")
            self.log("Startup countdown cancelled")
            return
        if self.runner and self.runner.alive:
            self.runner.stop()
            self._set_status("Stopping...")
        else:
            was_stale = self.session_start is not None
            self.session_start = None
            self.runner_launch_time = None
            self._set_running_ui(False)
            self._set_status("IDLE")
            if was_stale:
                self.log("Recovered controls after the playback worker exited.")
            else:
                self.log("The macro is not running.")

    def cmd_record(self):
        if self.runner and self.runner.alive:
            return
        if self.recorder and self.recorder.active:
            rec = self.recorder.stop()
            self.btn_start.configure(state="normal")
            self.profile_start_button.configure(state="normal")
            self._set_status("Idle")
            if len(rec["events"]) <= 1:
                return self.log("Nothing recorded")
            path = os.path.join(core.RECORDING_DIR, time.strftime("recording_%Y%m%d_%H%M%S.json"))
            core.save_recording(rec, path)
            self.log(f"Saved {len(rec['events'])} events ({rec['duration']:.1f}s) -> {os.path.basename(path)}")
            self._load_recording(path)
            return
        try:
            ignore = self.settings["hotkeys"].values()
            self.recorder = core.Recorder(ignore_keys=ignore)
            self.recorder.start()
        except Exception as exc:
            return messagebox.showerror("Can't record", f"{type(exc).__name__}: {exc}\n\n"
                                        "Install the requirements: pip install -r requirements.txt")
        self.btn_start.configure(state="disabled")
        self.profile_start_button.configure(state="disabled")
        self._set_status("RECORDING...")
        self.log(f"Recording - press {self.settings['hotkeys']['record'].upper()} again to stop")

    def _load_recording(self, path, quiet=False):
        if not path or not os.path.exists(path):
            return
        try:
            self.rec = core.load_recording(path)
        except Exception as exc:
            return self.log(f"Could not load recording: {exc}")
        self.settings["recording"] = path
        core.save_settings(self.settings)
        self.rec_var.set(f"Recording: {os.path.basename(path)}  "
                         f"({len(self.rec['events'])} events, {self.rec.get('duration', 0):.1f}s)")
        self.profile_var.set(os.path.splitext(os.path.basename(path))[0].replace("_", " ").title())
        self.profile_detail_var.set(f"{len(self.rec['events'])} actions  ·  {self.rec.get('duration', 0):.0f} sec  ·  Ready to run")
        self.btn_start.configure(state="normal")
        if not quiet:
            self.log(f"Loaded {os.path.basename(path)}")

    def load_dialog(self):
        path = filedialog.askopenfilename(initialdir=core.RECORDING_DIR, title="Load recording",
                                          filetypes=[("Recording", "*.json *.luvmacro *.txt"), ("All files", "*.*")])
        if path:
            self._load_recording(path)

    def reset_stats(self):
        if messagebox.askyesno("Reset stats", "Reset all counters to zero?"):
            self.stats.update(core.EMPTY_STATS)
            core.save_stats(self.stats)
            self._show_stats(self.stats)

    def check_window(self):
        self._apply_settings()
        r = core.find_window_rect(self.settings["window_title"])
        if r:
            self.log(f"Found the game window: {r[2]}x{r[3]} at ({r[0]}, {r[1]}) "
                     "(the game picture, without the title bar). Keep the macro window off it.")
        else:
            self.log(f"No visible window titled '{self.settings['window_title']}' found. Open the game "
                     "(not minimized); the title must match exactly (Roblox's is 'Roblox').")

    # ------------------------------------------------------------------ detection test
    def test_detection(self):
        """Look at the screen like the macro does and say how well each template matches."""
        if self.runner and self.runner.alive:
            return self.log("Stop the macro before testing")
        self._apply_settings()
        self.log("Detection test: looking at the screen in 3 seconds - show the screen you want to "
                 "test in the game (e.g. the Mission Completed / end screen)")
        self.root.after(3000, lambda: threading.Thread(target=self._detection_worker, daemon=True).start())

    def _detection_worker(self):
        say = lambda m: self.q.put(("log", m))
        try:
            r = core.diagnose_screen(self.settings)
        except Exception as exc:
            return say(f"Detection test failed: {type(exc).__name__}: {exc}")
        mon = r["monitor"]
        say(f"Looking at: {mon['width']}x{mon['height']} screen at ({mon['left']}, {mon['top']})")
        if r["brightness"] < 3:
            say("WARNING: the capture is BLACK - Windows can not capture the game (exclusive "
                "fullscreen?). Try borderless / windowed fullscreen.")
        need = self.settings["threshold"]
        for t in r["templates"]:
            if not t["exists"]:
                say(f"  {t['name']}: no image captured")
            elif t["found"]:
                say(f"  {t['name']}: FOUND (score {t['score']:.2f}, needs {need:.2f}) at {t['pos']}")
            else:
                line = f"  {t['name']}: not found (score {t['score']:.2f}, needs {need:.2f})"
                if t["best_score"] >= need and t["best_scale"] != 1.0:
                    line += (f" - but it matches at size x{t['best_scale']:g} ({t['best_score']:.2f}): the game "
                             "is shown at a different size than when you captured it")
                say(line)
        say("Saved debug/screen.png - open it to see exactly what the macro sees "
            "(green box = found, red = best guess)")

    # ------------------------------------------------------------------ template capture
    def capture_template(self):
        name = self.tpl_var.get()
        messagebox.showinfo("Capture", f"Get the game showing the '{name}' thing on screen, then "
                            "press OK. This window hides and you can drag a box around it.\n"
                            "Esc cancels. Keep the box tight and unique.")
        self.root.withdraw()
        self.root.after(300, lambda: self._snip(name))

    def _snip(self, name):
        top = tk.Toplevel(self.root)
        top.attributes("-fullscreen", True)
        top.attributes("-topmost", True)
        top.attributes("-alpha", 0.3)
        top.configure(bg="black")
        cv = tk.Canvas(top, bg="black", highlightthickness=0, cursor="crosshair")
        cv.pack(fill="both", expand=True)
        st = {}

        def press(e):
            st.update(x0=e.x_root, y0=e.y_root, cx=e.x, cy=e.y)
            st["rect"] = cv.create_rectangle(e.x, e.y, e.x, e.y, outline="red", width=2)

        def drag(e):
            if "rect" in st:
                cv.coords(st["rect"], st["cx"], st["cy"], e.x, e.y)

        def release(e):
            if "x0" not in st:
                return
            x0, y0, x1, y1 = st["x0"], st["y0"], e.x_root, e.y_root
            top.destroy()
            self.root.after(250, lambda: self._save_snip(
                name, min(x0, x1), min(y0, y1), abs(x1 - x0), abs(y1 - y0)))

        def cancel(_=None):
            top.destroy()
            self.root.deiconify()

        cv.bind("<ButtonPress-1>", press)
        cv.bind("<B1-Motion>", drag)
        cv.bind("<ButtonRelease-1>", release)
        top.bind("<Escape>", cancel)
        top.focus_force()

    def _save_snip(self, name, x, y, w, h):
        self.root.deiconify()
        if w < 8 or h < 8:
            return self.log("Region too small - nothing saved")
        try:
            import mss
            with mss.mss() as sct:
                shot = sct.grab({"left": x, "top": y, "width": w, "height": h})
            img = np.ascontiguousarray(np.asarray(shot)[:, :, :3])
            ok, buf = cv2.imencode(".png", img)
            buf.tofile(os.path.join(core.TEMPLATE_DIR, name + ".png"))
            ref = core.capture_area(self.settings)["height"]      # so it still matches if the window is resized
            with open(os.path.join(core.TEMPLATE_DIR, name + ".json"), "w", encoding="utf-8") as f:
                json.dump({"ref_h": ref}, f)
            self.log(f"Saved template '{name}' ({w}x{h}, captured with the game {ref}px high)")
        except Exception as exc:
            self.log(f"Capture failed: {exc}")
        self._refresh_templates()

    # ------------------------------------------------------------------ event pump
    def _pump(self):
        try:
            self._pump_body()
        except Exception as exc:
            if not self._pump_error_logged:
                self._pump_error_logged = True
                try:
                    self.log(f"UI event loop error: {type(exc).__name__}: {exc}", remote=False)
                    self._set_status("UI ERROR")
                except Exception:
                    pass
        finally:
            try:
                if self.root.winfo_exists():
                    self.root.after(100, self._pump)
            except tk.TclError:
                pass

    def _pump_body(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "cmd":
                    {"start": self.cmd_start, "pause": self.cmd_pause,
                     "stop": self.cmd_stop, "record": self.cmd_record}[payload]()
                elif kind == "log":
                    self.log(payload)
                elif kind == "discord_error":
                    self.log(payload, remote=False)
                elif kind == "fatal":
                    self.log("Playback stopped with an error: " + payload, remote=False)
                    messagebox.showerror("Playback failed", payload)
                elif kind == "status":
                    self._set_status(payload)
                elif kind == "stats":
                    self._show_stats(payload)
                elif kind == "finished":
                    self._set_running_ui(False)
                    self.btn_pause.configure(text=f"Pause ({self.settings['hotkeys']['pause'].upper()})")
                    self.session_start = None
                    self.runner_launch_time = None
        except queue.Empty:
            pass
        # A worker that exits without posting its usual completion event must not
        # leave playback controls disabled or the session timer running forever.
        if (self.session_start is not None and self.runner_launch_time is not None
                and time.monotonic() - self.runner_launch_time > 1.0
                and self.runner is not None and not self.runner.alive):
            self._set_running_ui(False)
            self.btn_pause.configure(text=f"Pause ({self.settings['hotkeys']['pause'].upper()})")
            self.session_start = None
            self.runner_launch_time = None
            self._set_status("IDLE")
            self.log("Playback worker exited unexpectedly; controls have been reset.")
        if self.session_start:
            s = int(time.time() - self.session_start)
            self.stat_vars["Session"].set(f"{s // 3600}:{s % 3600 // 60:02d}:{s % 60:02d}")

    def on_close(self):
        try:
            self.settings["window_pos"] = [int(self.root.winfo_x()), int(self.root.winfo_y())]
        except Exception:
            pass
        try:
            self._apply_settings()                  # keep whatever is typed in the settings fields
        except Exception:
            pass
        if self.runner and self.runner.alive:
            self.runner.stop()
        self.discord_log_stop.set()
        if self.recorder and self.recorder.active:
            self.recorder.stop()
        try:
            import keyboard
            keyboard.unhook_all()
        except Exception:
            pass
        self.root.destroy()


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()

