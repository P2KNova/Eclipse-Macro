param([Parameter(Mandatory=$true,ValueFromRemainingArguments=$true)][string[]]$ImagePaths)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null=[Windows.Storage.Streams.InMemoryRandomAccessStream,Windows.Storage,ContentType=WindowsRuntime]
$null=[Windows.Storage.Streams.DataWriter,Windows.Storage,ContentType=WindowsRuntime]
$null=[Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null=[Windows.Graphics.Imaging.SoftwareBitmap,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null=[Windows.Media.Ocr.OcrEngine,Windows.Media.Ocr,ContentType=WindowsRuntime]
$null=[Windows.Media.Ocr.OcrResult,Windows.Media.Ocr,ContentType=WindowsRuntime]
function Wait-Op($Op, [Type]$ResultType) {
  $m=[System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1
  } | Select-Object -First 1
  if ($null -eq $m) { throw 'Windows OCR async bridge is unavailable.' }
  $task=$m.MakeGenericMethod(@($ResultType)).Invoke($null,@($Op))
  $task.Wait()
  return $task.Result
}
$engine=[Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($null -eq $engine) { throw 'No Windows OCR language is installed.' }
foreach ($ImagePath in $ImagePaths) {
  $bytes=[System.IO.File]::ReadAllBytes((Resolve-Path -LiteralPath $ImagePath).Path)
  $stream=[Windows.Storage.Streams.InMemoryRandomAccessStream]::new()
  $writer=[Windows.Storage.Streams.DataWriter]::new($stream)
  $writer.WriteBytes($bytes)
  [void](Wait-Op ($writer.StoreAsync()) ([UInt32]))
  [void](Wait-Op ($writer.FlushAsync()) ([bool]))
  $stream.Seek(0)
  $decoder=Wait-Op ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $bitmap=Wait-Op ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  $result=Wait-Op ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
  $text=($result.Lines | ForEach-Object { $_.Text }) -join ' '
  Write-Output "__ECLIPSE_OCR__:$text"
}
